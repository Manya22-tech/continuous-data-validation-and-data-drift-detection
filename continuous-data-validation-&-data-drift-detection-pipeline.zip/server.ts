import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // Initialize Gemini client if API key is present
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return null;
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  };

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // AI-powered Drift Root Cause Diagnostic Endpoint
  app.post("/api/gemini/analyze-drift", async (req, res) => {
    try {
      const { datasetName, pipelineSummary, driftResults, validationErrors } = req.body;
      const ai = getGeminiClient();

      if (!ai) {
        return res.status(503).json({
          error: "Gemini API Key is not configured on the server. Defaulting to heuristic rule analyzer.",
          fallbackAnalysis: {
            summary: "Automated Heuristic Diagnostic: High statistical drift detected in key numerical features.",
            rootCause: "Observed distribution shift in feature values between reference training set and current operational batch.",
            businessImpact: "Risk of ML model performance degradation and silent prediction skew in production.",
            remediationSteps: [
              "Trigger automated dataset re-sampling and feature scaling validation.",
              "Quarantine incoming batch and evaluate retraining pipeline trigger.",
              "Verify upstream schema changes or sensor calibration drift."
            ]
          }
        });
      }

      const prompt = `
You are an expert Principal Machine Learning Reliability Engineer (MLOps Specialist) reviewing a continuous data drift and validation pipeline audit for an enterprise ML system.

Dataset Context: ${datasetName || "Enterprise ML Production Feature Pipeline"}
Pipeline Summary: ${JSON.stringify(pipelineSummary || {})}
Data Drift Findings: ${JSON.stringify(driftResults || []).slice(0, 1500)}
Validation Schema Violations: ${JSON.stringify(validationErrors || []).slice(0, 1000)}

Please generate a structured JSON diagnosis response with:
1. "summary": Concise executive summary (2-3 sentences) of data quality and drift state.
2. "rootCause": Most plausible real-world engineering or domain root cause for the observed drift/errors.
3. "businessImpact": Impact on ML model performance, accuracy metrics, and downstream decision systems.
4. "remediationSteps": Array of 3-4 concrete actionable engineering steps (e.g. model retraining, schema enforcement, data isolation).
5. "collegeExplanationTip": A 2-sentence quick tip for a student presenting this finding to their college professor/examiner.

Return ONLY raw JSON matching this structure without markdown code blocks.
`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        },
      });

      const responseText = response.text || "{}";
      let parsedData;
      try {
        parsedData = JSON.parse(responseText);
      } catch {
        parsedData = {
          summary: responseText.slice(0, 300),
          rootCause: "Distribution shift detected between baseline reference batch and operational inference batch.",
          businessImpact: "Potential degradation in prediction confidence and model accuracy.",
          remediationSteps: [
            "Initiate ML model retraining with updated reference batch.",
            "Enforce strict schema validation rules on ingress API.",
            "Review upstream feature engineering pipelines."
          ],
          collegeExplanationTip: "Highlight to examiners how statistical tests (PSI & KS-Test) caught this shift before model failure occurred."
        };
      }

      res.json(parsedData);
    } catch (err: any) {
      console.error("Gemini Analysis Error:", err);
      res.status(500).json({ error: err.message || "Failed to run AI diagnostic analysis" });
    }
  });

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
