import { FeatureSchema, DataRecord, SchemaViolation, ValidationSummary, FeatureDriftResult, HistogramBin, OverallDriftSummary } from '../types/pipeline';

// Helper: mean
export function calculateMean(arr: number[]): number {
  if (!arr.length) return 0;
  return arr.reduce((sum, val) => sum + val, 0) / arr.length;
}

// Helper: standard deviation
export function calculateStd(arr: number[], meanVal?: number): number {
  if (arr.length <= 1) return 0;
  const m = meanVal ?? calculateMean(arr);
  const variance = arr.reduce((sum, val) => sum + Math.pow(val - m, 2), 0) / (arr.length - 1);
  return Math.sqrt(variance);
}

// Kolmogorov-Smirnov 2-sample test calculation
export function calculateKSTest(baseline: number[], current: number[]): { statistic: number; pValue: number } {
  const n1 = baseline.length;
  const n2 = current.length;
  if (n1 === 0 || n2 === 0) return { statistic: 0, pValue: 1.0 };

  const sorted1 = [...baseline].sort((a, b) => a - b);
  const sorted2 = [...current].sort((a, b) => a - b);

  let i = 0;
  let j = 0;
  let maxD = 0;

  while (i < n1 && j < n2) {
    const val1 = sorted1[i];
    const val2 = sorted2[j];

    if (val1 === val2) {
      const v = val1;
      while (i < n1 && sorted1[i] === v) i++;
      while (j < n2 && sorted2[j] === v) j++;
    } else if (val1 < val2) {
      i++;
    } else {
      j++;
    }

    const cdf1 = i / n1;
    const cdf2 = j / n2;
    const d = Math.abs(cdf1 - cdf2);
    if (d > maxD) maxD = d;
  }

  // Asymptotic p-value approximation for Kolmogorov-Smirnov 2-sample
  const en = Math.sqrt((n1 * n2) / (n1 + n2));
  const lambda = (en + 0.12 + 0.11 / en) * maxD;

  let pValue = 1.0;
  if (lambda > 0) {
    // Kolmogorov distribution asymptotic expansion
    let sum = 0;
    for (let k = 1; k <= 20; k++) {
      sum += Math.pow(-1, k - 1) * Math.exp(-2 * k * k * lambda * lambda);
    }
    pValue = Math.min(1.0, Math.max(0.0, 2 * sum));
  }

  return {
    statistic: Number(maxD.toFixed(4)),
    pValue: Number(pValue.toFixed(4)),
  };
}

// Wasserstein Distance (1D Earth Mover's Distance)
export function calculateWassersteinDistance(baseline: number[], current: number[]): number {
  if (!baseline.length || !current.length) return 0;
  const s1 = [...baseline].sort((a, b) => a - b);
  const s2 = [...current].sort((a, b) => a - b);

  const points = 100;
  let totalDist = 0;

  for (let k = 0; k < points; k++) {
    const q = (k + 0.5) / points;
    const idx1 = Math.min(s1.length - 1, Math.floor(q * s1.length));
    const idx2 = Math.min(s2.length - 1, Math.floor(q * s2.length));
    totalDist += Math.abs(s1[idx1] - s2[idx2]);
  }

  return Number((totalDist / points).toFixed(4));
}

// Calculate Population Stability Index (PSI) and Histogram bins for numerical features
export function calculateNumericalPsiAndBins(
  baseline: number[],
  current: number[],
  numBins: number = 10
): { psiScore: number; bins: HistogramBin[] } {
  if (!baseline.length || !current.length) {
    return { psiScore: 0, bins: [] };
  }

  const allVals = [...baseline, ...current];
  const minVal = Math.min(...allVals);
  const maxVal = Math.max(...allVals);
  const range = maxVal - minVal || 1;
  const binWidth = range / numBins;

  const binEdges: number[] = [];
  for (let i = 0; i <= numBins; i++) {
    binEdges.push(minVal + i * binWidth);
  }

  const baselineCounts = new Array(numBins).fill(0);
  const currentCounts = new Array(numBins).fill(0);

  baseline.forEach((v) => {
    let idx = Math.floor((v - minVal) / binWidth);
    if (idx >= numBins) idx = numBins - 1;
    if (idx < 0) idx = 0;
    baselineCounts[idx]++;
  });

  current.forEach((v) => {
    let idx = Math.floor((v - minVal) / binWidth);
    if (idx >= numBins) idx = numBins - 1;
    if (idx < 0) idx = 0;
    currentCounts[idx]++;
  });

  const epsilon = 0.0001; // smoothing factor
  let totalPsi = 0;
  const bins: HistogramBin[] = [];

  for (let i = 0; i < numBins; i++) {
    const bStart = binEdges[i];
    const bEnd = binEdges[i + 1];
    const bCount = baselineCounts[i];
    const cCount = currentCounts[i];

    const bPct = Math.max(epsilon, bCount / baseline.length);
    const cPct = Math.max(epsilon, cCount / current.length);

    // PSI Formula: (Actual % - Expected %) * ln(Actual % / Expected %)
    const binPsi = (cPct - bPct) * Math.log(cPct / bPct);
    totalPsi += binPsi;

    bins.push({
      binLabel: `${bStart.toFixed(1)} - ${bEnd.toFixed(1)}`,
      binStart: Number(bStart.toFixed(2)),
      binEnd: Number(bEnd.toFixed(2)),
      baselinePct: Number((bPct * 100).toFixed(2)),
      currentPct: Number((cPct * 100).toFixed(2)),
      baselineCount: bCount,
      currentCount: cCount,
      binPsi: Number(binPsi.toFixed(4)),
    });
  }

  return {
    psiScore: Number(totalPsi.toFixed(4)),
    bins,
  };
}

// Chi-Square Goodness-of-fit for Categorical Features
export function calculateCategoricalDrift(
  baseline: string[],
  current: string[]
): {
  psiScore: number;
  chiSquareStat: number;
  chiSquarePValue: number;
  distribution: { category: string; baselinePct: number; currentPct: number }[];
  unseenCategories: string[];
} {
  const baseFreqMap: Record<string, number> = {};
  const currFreqMap: Record<string, number> = {};

  baseline.forEach((c) => {
    const key = String(c || 'NULL').trim();
    baseFreqMap[key] = (baseFreqMap[key] || 0) + 1;
  });

  current.forEach((c) => {
    const key = String(c || 'NULL').trim();
    currFreqMap[key] = (currFreqMap[key] || 0) + 1;
  });

  const allCategories = Array.from(new Set([...Object.keys(baseFreqMap), ...Object.keys(currFreqMap)]));
  const unseenCategories = Object.keys(currFreqMap).filter((cat) => !baseFreqMap[cat]);

  let chiSquare = 0;
  let totalPsi = 0;
  const epsilon = 0.0001;

  const distribution = allCategories.map((cat) => {
    const bCount = baseFreqMap[cat] || 0;
    const cCount = currFreqMap[cat] || 0;

    const bPct = Math.max(epsilon, bCount / (baseline.length || 1));
    const cPct = Math.max(epsilon, cCount / (current.length || 1));

    // Chi-square term
    const expectedCount = Math.max(0.5, (bCount / baseline.length) * current.length);
    const chiTerm = Math.pow(cCount - expectedCount, 2) / expectedCount;
    chiSquare += chiTerm;

    // PSI term
    const binPsi = (cPct - bPct) * Math.log(cPct / bPct);
    totalPsi += binPsi;

    return {
      category: cat,
      baselinePct: Number((bPct * 100).toFixed(2)),
      currentPct: Number((cPct * 100).toFixed(2)),
    };
  });

  // Rough Chi-square p-value estimate based on df = categories - 1
  const df = Math.max(1, allCategories.length - 1);
  const chiSqNormalized = chiSquare / df;
  let pValue = 1.0;
  if (chiSqNormalized > 3.84) pValue = 0.001;
  else if (chiSqNormalized > 2.71) pValue = 0.05;
  else if (chiSqNormalized > 1.64) pValue = 0.15;
  else pValue = 0.50;

  return {
    psiScore: Number(totalPsi.toFixed(4)),
    chiSquareStat: Number(chiSquare.toFixed(2)),
    chiSquarePValue: pValue,
    distribution,
    unseenCategories,
  };
}

// Evaluate Schema Validation Rules against a Batch
export function evaluateSchemaValidation(
  schemas: FeatureSchema[],
  batchData: DataRecord[]
): ValidationSummary {
  const violations: SchemaViolation[] = [];
  let passedCount = 0;
  let failedCount = 0;

  const totalRecords = batchData.length;

  schemas.forEach((schema) => {
    const featureName = schema.name;
    const values = batchData.map((row) => row[featureName]);

    // Rule 1: Check column existence
    const exists = batchData.some((row) => Object.prototype.hasOwnProperty.call(row, featureName));
    if (!exists) {
      failedCount++;
      violations.push({
        id: `miss_${featureName}`,
        featureName,
        violationType: 'MISSING_COLUMN',
        severity: 'CRITICAL',
        affectedCount: totalRecords,
        affectedPercentage: 100,
        description: `Feature '${featureName}' is missing completely from the ingestion payload.`,
        suggestedFix: `Check upstream database query or API contract. Feature is mandatory for ML model scoring.`,
      });
      return;
    } else {
      passedCount++;
    }

    // Rule 2: Null value percentage
    const nullCount = values.filter((v) => v === null || v === undefined || v === '' || Number.isNaN(v)).length;
    const nullPct = (nullCount / totalRecords) * 100;

    if (!schema.allowNulls && nullCount > 0) {
      failedCount++;
      violations.push({
        id: `null_strict_${featureName}`,
        featureName,
        violationType: 'NULL_THRESHOLD_EXCEEDED',
        severity: 'CRITICAL',
        affectedCount: nullCount,
        affectedPercentage: Number(nullPct.toFixed(1)),
        description: `Found ${nullCount} null/empty values in non-nullable feature '${featureName}'.`,
        suggestedFix: `Impute missing values using training median/mode or drop records prior to inference.`,
      });
    } else if (nullPct > schema.maxNullPercentage) {
      failedCount++;
      violations.push({
        id: `null_pct_${featureName}`,
        featureName,
        violationType: 'NULL_THRESHOLD_EXCEEDED',
        severity: 'WARNING',
        affectedCount: nullCount,
        affectedPercentage: Number(nullPct.toFixed(1)),
        description: `Null percentage (${nullPct.toFixed(1)}%) exceeds configured maximum threshold (${schema.maxNullPercentage}%).`,
        suggestedFix: `Verify sensor/feed connectivity or apply automated baseline median imputation.`,
      });
    } else {
      passedCount++;
    }

    // Rule 3: Data Type and Domain Range Checks
    if (schema.type === 'numerical') {
      const nonNullNums = values.filter((v) => typeof v === 'number' && !Number.isNaN(v));
      const typeMismatchCount = values.filter((v) => v !== null && v !== undefined && (typeof v !== 'number' || Number.isNaN(v))).length;

      if (typeMismatchCount > 0) {
        failedCount++;
        violations.push({
          id: `type_${featureName}`,
          featureName,
          violationType: 'TYPE_MISMATCH',
          severity: 'CRITICAL',
          affectedCount: typeMismatchCount,
          affectedPercentage: Number(((typeMismatchCount / totalRecords) * 100).toFixed(1)),
          description: `Feature '${featureName}' contains non-numeric strings or invalid numbers.`,
          suggestedFix: `Apply type casting filter (e.g. pd.to_numeric) and reject corrupted records.`,
        });
      } else {
        passedCount++;
      }

      if (schema.minAllowed !== undefined || schema.maxAllowed !== undefined) {
        const outOfBounds = nonNullNums.filter((val) => {
          if (schema.minAllowed !== undefined && val < schema.minAllowed) return true;
          if (schema.maxAllowed !== undefined && val > schema.maxAllowed) return true;
          return false;
        });

        if (outOfBounds.length > 0) {
          failedCount++;
          violations.push({
            id: `range_${featureName}`,
            featureName,
            violationType: 'RANGE_OUT_OF_BOUNDS',
            severity: 'WARNING',
            affectedCount: outOfBounds.length,
            affectedPercentage: Number(((outOfBounds.length / totalRecords) * 100).toFixed(1)),
            description: `${outOfBounds.length} records fell outside expected domain boundaries [${schema.minAllowed ?? '-∞'}, ${schema.maxAllowed ?? '+∞'}].`,
            suggestedFix: `Clip outlier feature values to valid training bounds or mark as anomaly.`,
          });
        } else {
          passedCount++;
        }
      }
    } else if (schema.type === 'categorical' && schema.allowedCategories?.length) {
      const invalidCategories = values.filter(
        (v) => v !== null && v !== undefined && v !== '' && !schema.allowedCategories!.includes(String(v))
      );

      if (invalidCategories.length > 0) {
        failedCount++;
        violations.push({
          id: `cat_${featureName}`,
          featureName,
          violationType: 'UNALLOWED_CATEGORY',
          severity: 'WARNING',
          affectedCount: invalidCategories.length,
          affectedPercentage: Number(((invalidCategories.length / totalRecords) * 100).toFixed(1)),
          description: `Encountered unapproved categories (e.g., '${invalidCategories[0]}') not seen in training schema.`,
          suggestedFix: `Map novel categories to 'OTHER' token or update baseline categorical encodings.`,
        });
      } else {
        passedCount++;
      }
    }
  });

  const totalRules = passedCount + failedCount;
  const healthScore = totalRules > 0 ? Math.round((passedCount / totalRules) * 100) : 100;

  return {
    totalRecordsChecked: totalRecords,
    totalFeaturesChecked: schemas.length,
    passedRulesCount: passedCount,
    failedRulesCount: failedCount,
    healthScore,
    violations,
  };
}

// Calculate Full Data Drift Analysis for all features
export function analyzeFullDataDrift(
  schemas: FeatureSchema[],
  baselineData: DataRecord[],
  currentData: DataRecord[]
): { featureResults: FeatureDriftResult[]; summary: OverallDriftSummary } {
  const featureResults: FeatureDriftResult[] = [];

  let totalPsiSum = 0;
  let maxKs = 0;
  let driftedCount = 0;
  let criticalCount = 0;
  let moderateCount = 0;
  let noDriftCount = 0;

  schemas.forEach((schema) => {
    const featureName = schema.name;

    if (schema.type === 'numerical') {
      const baseVals = baselineData
        .map((r) => r[featureName])
        .filter((v) => typeof v === 'number' && !Number.isNaN(v)) as number[];
      const currVals = currentData
        .map((r) => r[featureName])
        .filter((v) => typeof v === 'number' && !Number.isNaN(v)) as number[];

      const baseMean = calculateMean(baseVals);
      const currMean = calculateMean(currVals);
      const baseStd = calculateStd(baseVals, baseMean);
      const currStd = calculateStd(currVals, currMean);

      const meanShiftPct = baseMean !== 0 ? Number((((currMean - baseMean) / baseMean) * 100).toFixed(1)) : 0;

      const ks = calculateKSTest(baseVals, currVals);
      const wasserstein = calculateWassersteinDistance(baseVals, currVals);
      const { psiScore, bins } = calculateNumericalPsiAndBins(baseVals, currVals);

      if (ks.statistic > maxKs) maxKs = ks.statistic;
      totalPsiSum += psiScore;

      // Classify drift level based on industry standard PSI criteria:
      // PSI < 0.10 => NO_DRIFT
      // 0.10 <= PSI < 0.25 => MODERATE_DRIFT
      // PSI >= 0.25 => CRITICAL_DRIFT
      let driftStatus: 'NO_DRIFT' | 'MODERATE_DRIFT' | 'CRITICAL_DRIFT' = 'NO_DRIFT';
      if (psiScore >= 0.25 || ks.statistic >= 0.35) {
        driftStatus = 'CRITICAL_DRIFT';
        criticalCount++;
        driftedCount++;
      } else if (psiScore >= 0.10 || ks.statistic >= 0.18) {
        driftStatus = 'MODERATE_DRIFT';
        moderateCount++;
        driftedCount++;
      } else {
        noDriftCount++;
      }

      featureResults.push({
        featureName,
        featureType: 'numerical',
        baselineMean: Number(baseMean.toFixed(2)),
        currentMean: Number(currMean.toFixed(2)),
        meanShiftPct,
        baselineStd: Number(baseStd.toFixed(2)),
        currentStd: Number(currStd.toFixed(2)),
        ksStatistic: ks.statistic,
        ksPValue: ks.pValue,
        psiScore,
        wassersteinDistance: wasserstein,
        driftStatus,
        bins,
      });
    } else {
      // Categorical
      const baseVals = baselineData.map((r) => String(r[featureName] || ''));
      const currVals = currentData.map((r) => String(r[featureName] || ''));

      const catDrift = calculateCategoricalDrift(baseVals, currVals);
      totalPsiSum += catDrift.psiScore;

      let driftStatus: 'NO_DRIFT' | 'MODERATE_DRIFT' | 'CRITICAL_DRIFT' = 'NO_DRIFT';
      if (catDrift.psiScore >= 0.25 || catDrift.unseenCategories.length > 0) {
        driftStatus = 'CRITICAL_DRIFT';
        criticalCount++;
        driftedCount++;
      } else if (catDrift.psiScore >= 0.10) {
        driftStatus = 'MODERATE_DRIFT';
        moderateCount++;
        driftedCount++;
      } else {
        noDriftCount++;
      }

      featureResults.push({
        featureName,
        featureType: 'categorical',
        psiScore: catDrift.psiScore,
        chiSquareStat: catDrift.chiSquareStat,
        chiSquarePValue: catDrift.chiSquarePValue,
        driftStatus,
        bins: [],
        categoricalDistribution: catDrift.distribution,
        unseenCategoriesFound: catDrift.unseenCategories,
      });
    }
  });

  const avgPsi = schemas.length > 0 ? Number((totalPsiSum / schemas.length).toFixed(4)) : 0;
  // Estimated accuracy degradation formula for presentation context
  const predictedModelAccuracyDrop = Number((avgPsi * 28.5 + criticalCount * 4.2).toFixed(1));

  let overallStatus: 'STABLE' | 'MODERATE_WARNING' | 'CRITICAL_ACTION_REQUIRED' = 'STABLE';
  if (criticalCount > 0 || avgPsi >= 0.20) {
    overallStatus = 'CRITICAL_ACTION_REQUIRED';
  } else if (moderateCount > 0 || avgPsi >= 0.08) {
    overallStatus = 'MODERATE_WARNING';
  }

  return {
    featureResults,
    summary: {
      totalFeatures: schemas.length,
      driftedFeaturesCount: driftedCount,
      criticalDriftCount: criticalCount,
      moderateDriftCount: moderateCount,
      noDriftCount,
      averagePsi: avgPsi,
      maxKsStatistic: maxKs,
      predictedModelAccuracyDrop: Math.min(45, predictedModelAccuracyDrop),
      overallStatus,
    },
  };
}
