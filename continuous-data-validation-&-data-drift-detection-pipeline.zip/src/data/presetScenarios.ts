import { BatchScenario, FeatureSchema, DataRecord } from '../types/pipeline';

// Helper to generate pseudorandom normal distribution
function randomNormal(mean: number, std: number): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return mean + num * std;
}

// 1. Credit Card Fraud Scenario Data Generator
function generateFraudData(): {
  schemas: FeatureSchema[];
  baseline: DataRecord[];
  normalBatch: DataRecord[];
  driftBatch: DataRecord[];
  corruptBatch: DataRecord[];
} {
  const schemas: FeatureSchema[] = [
    {
      name: 'transaction_amount',
      type: 'numerical',
      unit: 'USD',
      minAllowed: 0.01,
      maxAllowed: 10000,
      allowNulls: false,
      maxNullPercentage: 0,
      description: 'Transaction value in USD',
    },
    {
      name: 'credit_score',
      type: 'numerical',
      unit: 'pts',
      minAllowed: 300,
      maxAllowed: 850,
      allowNulls: false,
      maxNullPercentage: 1,
      description: 'User FICO credit score',
    },
    {
      name: 'daily_transactions',
      type: 'numerical',
      unit: 'count',
      minAllowed: 0,
      maxAllowed: 50,
      allowNulls: false,
      maxNullPercentage: 2,
      description: 'Number of card swipes in past 24h',
    },
    {
      name: 'user_age',
      type: 'numerical',
      unit: 'years',
      minAllowed: 18,
      maxAllowed: 100,
      allowNulls: false,
      maxNullPercentage: 1,
      description: 'Account holder age',
    },
    {
      name: 'device_type',
      type: 'categorical',
      allowedCategories: ['iOS', 'Android', 'Web', 'POS_Terminal'],
      allowNulls: false,
      maxNullPercentage: 1,
      description: 'Device hardware channel',
    },
    {
      name: 'location_risk_score',
      type: 'numerical',
      unit: 'index',
      minAllowed: 0,
      maxAllowed: 1,
      allowNulls: false,
      maxNullPercentage: 2,
      description: 'Geographic fraud risk index (0=Safe, 1=High Risk)',
    },
  ];

  const devices = ['iOS', 'Android', 'Web', 'POS_Terminal'];

  // Generate 200 Baseline training rows
  const baseline: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    baseline.push({
      id: `base_${i}`,
      transaction_amount: Number(Math.max(1, randomNormal(65, 25)).toFixed(2)),
      credit_score: Math.round(Math.min(850, Math.max(300, randomNormal(710, 45)))),
      daily_transactions: Math.round(Math.max(1, randomNormal(4, 2))),
      user_age: Math.round(Math.min(85, Math.max(18, randomNormal(38, 11)))),
      device_type: devices[i % devices.length],
      location_risk_score: Number(Math.min(1, Math.max(0, randomNormal(0.15, 0.08))).toFixed(2)),
    });
  }

  // Normal Ingestion Batch (stable distribution)
  const normalBatch: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    normalBatch.push({
      id: `norm_${i}`,
      transaction_amount: Number(Math.max(1, randomNormal(68, 26)).toFixed(2)),
      credit_score: Math.round(Math.min(850, Math.max(300, randomNormal(708, 48)))),
      daily_transactions: Math.round(Math.max(1, randomNormal(4.2, 2.1))),
      user_age: Math.round(Math.min(85, Math.max(18, randomNormal(39, 10)))),
      device_type: devices[(i + 1) % devices.length],
      location_risk_score: Number(Math.min(1, Math.max(0, randomNormal(0.16, 0.09))).toFixed(2)),
    });
  }

  // Covariate Drift Batch (Holiday Season Surge: higher amounts, high daily velocity, risk score shift)
  const driftBatch: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    driftBatch.push({
      id: `drift_${i}`,
      transaction_amount: Number(Math.max(5, randomNormal(195, 85)).toFixed(2)), // Shifted mean from 65 to 195
      credit_score: Math.round(Math.min(850, Math.max(300, randomNormal(670, 60)))),
      daily_transactions: Math.round(Math.max(1, randomNormal(12, 5))), // Shifted mean from 4 to 12
      user_age: Math.round(Math.min(85, Math.max(18, randomNormal(41, 14)))),
      device_type: i % 10 === 0 ? 'SmartWatch_NFC' : devices[i % 3], // Unseen category 'SmartWatch_NFC'
      location_risk_score: Number(Math.min(1, Math.max(0, randomNormal(0.48, 0.22))).toFixed(2)), // Elevated risk
    });
  }

  // Schema Corruption Batch (Null credit scores, negative amounts, out of bounds)
  const corruptBatch: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    const isNullScore = i % 8 === 0;
    const isNegativeAmt = i % 15 === 0;

    corruptBatch.push({
      id: `corrupt_${i}`,
      transaction_amount: isNegativeAmt ? -45.50 : Number(Math.max(1, randomNormal(70, 30)).toFixed(2)),
      credit_score: isNullScore ? null : Math.round(Math.min(850, Math.max(300, randomNormal(700, 50)))),
      daily_transactions: i % 20 === 0 ? 99 : Math.round(Math.max(1, randomNormal(4, 2))), // Range violation 99 > 50
      user_age: Math.round(Math.min(85, Math.max(18, randomNormal(38, 11)))),
      device_type: i % 12 === 0 ? 'UNKNOWN_BOT' : devices[i % devices.length],
      location_risk_score: Number(Math.min(1, Math.max(0, randomNormal(0.18, 0.1))).toFixed(2)),
    });
  }

  return { schemas, baseline, normalBatch, driftBatch, corruptBatch };
}

// 2. Customer Churn Data Generator
function generateChurnData(): {
  schemas: FeatureSchema[];
  baseline: DataRecord[];
  normalBatch: DataRecord[];
  driftBatch: DataRecord[];
  corruptBatch: DataRecord[];
} {
  const schemas: FeatureSchema[] = [
    {
      name: 'monthly_charges',
      type: 'numerical',
      unit: 'USD',
      minAllowed: 10,
      maxAllowed: 300,
      allowNulls: false,
      maxNullPercentage: 0,
      description: 'Monthly customer invoice billing amount',
    },
    {
      name: 'tenure_months',
      type: 'numerical',
      unit: 'months',
      minAllowed: 0,
      maxAllowed: 120,
      allowNulls: false,
      maxNullPercentage: 1,
      description: 'Account tenure duration in months',
    },
    {
      name: 'support_tickets_30d',
      type: 'numerical',
      unit: 'tickets',
      minAllowed: 0,
      maxAllowed: 20,
      allowNulls: false,
      maxNullPercentage: 2,
      description: 'Customer support complaints filed in last 30 days',
    },
    {
      name: 'contract_type',
      type: 'categorical',
      allowedCategories: ['Month-to-Month', 'One-Year', 'Two-Year'],
      allowNulls: false,
      maxNullPercentage: 0,
      description: 'Subscription commitment contract type',
    },
    {
      name: 'data_usage_gb',
      type: 'numerical',
      unit: 'GB',
      minAllowed: 0,
      maxAllowed: 2000,
      allowNulls: false,
      maxNullPercentage: 3,
      description: 'Monthly cellular data consumption in GB',
    },
  ];

  const contracts = ['Month-to-Month', 'One-Year', 'Two-Year'];

  const baseline: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    baseline.push({
      id: `churn_base_${i}`,
      monthly_charges: Number(Math.max(15, randomNormal(64, 18)).toFixed(2)),
      tenure_months: Math.round(Math.max(1, randomNormal(32, 16))),
      support_tickets_30d: Math.round(Math.max(0, randomNormal(1.2, 1.1))),
      contract_type: contracts[i % contracts.length],
      data_usage_gb: Number(Math.max(5, randomNormal(120, 45)).toFixed(1)),
    });
  }

  const normalBatch: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    normalBatch.push({
      id: `churn_norm_${i}`,
      monthly_charges: Number(Math.max(15, randomNormal(65, 19)).toFixed(2)),
      tenure_months: Math.round(Math.max(1, randomNormal(33, 15))),
      support_tickets_30d: Math.round(Math.max(0, randomNormal(1.3, 1.0))),
      contract_type: contracts[(i + 1) % contracts.length],
      data_usage_gb: Number(Math.max(5, randomNormal(122, 42)).toFixed(1)),
    });
  }

  // Price Increase + System Outage Shift (Monthly charges raised to $105, support tickets spiked to 5.8)
  const driftBatch: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    driftBatch.push({
      id: `churn_drift_${i}`,
      monthly_charges: Number(Math.max(15, randomNormal(108, 28)).toFixed(2)), // Shifted up
      tenure_months: Math.round(Math.max(1, randomNormal(22, 12))), // Shorter tenure active
      support_tickets_30d: Math.round(Math.max(0, randomNormal(5.8, 2.4))), // Support tickets spiked
      contract_type: i % 12 === 0 ? 'Crypto_Flex' : contracts[i % 2], // Shift towards Month-to-Month + unseen category
      data_usage_gb: Number(Math.max(5, randomNormal(280, 95)).toFixed(1)), // Data surge
    });
  }

  const corruptBatch: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    corruptBatch.push({
      id: `churn_corrupt_${i}`,
      monthly_charges: Number(Math.max(15, randomNormal(64, 18)).toFixed(2)),
      tenure_months: i % 10 === 0 ? null : Math.round(Math.max(1, randomNormal(32, 16))), // 10% Nulls
      support_tickets_30d: i % 15 === 0 ? -3 : Math.round(Math.max(0, randomNormal(1.2, 1.1))), // Negative counts
      contract_type: i % 10 === 0 ? null : contracts[i % contracts.length],
      data_usage_gb: Number(Math.max(5, randomNormal(120, 45)).toFixed(1)),
    });
  }

  return { schemas, baseline, normalBatch, driftBatch, corruptBatch };
}

// 3. Health & ICU Risk Scenario
function generateHealthData(): {
  schemas: FeatureSchema[];
  baseline: DataRecord[];
  normalBatch: DataRecord[];
  driftBatch: DataRecord[];
  corruptBatch: DataRecord[];
} {
  const schemas: FeatureSchema[] = [
    {
      name: 'glucose_mg_dl',
      type: 'numerical',
      unit: 'mg/dL',
      minAllowed: 50,
      maxAllowed: 400,
      allowNulls: false,
      maxNullPercentage: 1,
      description: 'Blood glucose level',
    },
    {
      name: 'blood_pressure_sys',
      type: 'numerical',
      unit: 'mmHg',
      minAllowed: 70,
      maxAllowed: 220,
      allowNulls: false,
      maxNullPercentage: 1,
      description: 'Systolic blood pressure',
    },
    {
      name: 'heart_rate_bpm',
      type: 'numerical',
      unit: 'bpm',
      minAllowed: 40,
      maxAllowed: 180,
      allowNulls: false,
      maxNullPercentage: 1,
      description: 'Heart rate in beats per minute',
    },
    {
      name: 'oxygen_saturation',
      type: 'numerical',
      unit: '%',
      minAllowed: 70,
      maxAllowed: 100,
      allowNulls: false,
      maxNullPercentage: 0,
      description: 'Pulse oximeter SPO2 percentage',
    },
  ];

  const baseline: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    baseline.push({
      id: `icu_base_${i}`,
      glucose_mg_dl: Math.round(Math.min(300, Math.max(60, randomNormal(105, 22)))),
      blood_pressure_sys: Math.round(Math.min(190, Math.max(80, randomNormal(120, 14)))),
      heart_rate_bpm: Math.round(Math.min(150, Math.max(50, randomNormal(74, 11)))),
      oxygen_saturation: Math.round(Math.min(100, Math.max(88, randomNormal(97.5, 1.8)))),
    });
  }

  const normalBatch: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    normalBatch.push({
      id: `icu_norm_${i}`,
      glucose_mg_dl: Math.round(Math.min(300, Math.max(60, randomNormal(107, 23)))),
      blood_pressure_sys: Math.round(Math.min(190, Math.max(80, randomNormal(121, 15)))),
      heart_rate_bpm: Math.round(Math.min(150, Math.max(50, randomNormal(75, 10)))),
      oxygen_saturation: Math.round(Math.min(100, Math.max(88, randomNormal(97.4, 1.7)))),
    });
  }

  // Sensor Calibration Shift: Glucose calibration shifted +42 mg/dL, SPO2 sensor degradation
  const driftBatch: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    driftBatch.push({
      id: `icu_drift_${i}`,
      glucose_mg_dl: Math.round(Math.min(400, Math.max(60, randomNormal(152, 45)))), // Shifted up
      blood_pressure_sys: Math.round(Math.min(210, Math.max(80, randomNormal(138, 22)))), // Elevated BP
      heart_rate_bpm: Math.round(Math.min(170, Math.max(50, randomNormal(92, 18)))), // Tachycardia shift
      oxygen_saturation: Math.round(Math.min(100, Math.max(75, randomNormal(93.2, 3.8)))), // Lower SPO2
    });
  }

  const corruptBatch: DataRecord[] = [];
  for (let i = 1; i <= 200; i++) {
    corruptBatch.push({
      id: `icu_corrupt_${i}`,
      glucose_mg_dl: i % 12 === 0 ? null : Math.round(Math.min(300, Math.max(60, randomNormal(105, 22)))),
      blood_pressure_sys: i % 20 === 0 ? 350 : Math.round(Math.min(190, Math.max(80, randomNormal(120, 14)))), // Out of bounds 350 > 220
      heart_rate_bpm: Math.round(Math.min(150, Math.max(50, randomNormal(74, 11)))),
      oxygen_saturation: i % 7 === 0 ? null : Math.round(Math.min(100, Math.max(88, randomNormal(97.5, 1.8)))), // Nulls in non-null SPO2
    });
  }

  return { schemas, baseline, normalBatch, driftBatch, corruptBatch };
}

export function getPresetScenarios(): {
  fraud: { scenario: BatchScenario; normalBatch: DataRecord[]; driftBatch: DataRecord[]; corruptBatch: DataRecord[] };
  churn: { scenario: BatchScenario; normalBatch: DataRecord[]; driftBatch: DataRecord[]; corruptBatch: DataRecord[] };
  health: { scenario: BatchScenario; normalBatch: DataRecord[]; driftBatch: DataRecord[]; corruptBatch: DataRecord[] };
} {
  const fraud = generateFraudData();
  const churn = generateChurnData();
  const health = generateHealthData();

  return {
    fraud: {
      scenario: {
        id: 'fraud_detection',
        name: 'Credit Card Fraud Detection ML Pipeline',
        domain: 'FinTech & Banking ML',
        targetModel: 'XGBoost Fraud Classifier v2.4',
        description: 'Monitors real-time payment transaction feeds against baseline training dataset to detect covariate drift during holiday shopping rushes and payment API schema corruptions.',
        schemas: fraud.schemas,
        baselineData: fraud.baseline,
        currentBatchData: fraud.driftBatch,
        scenarioNotes: {
          normalBatchDesc: 'Batch 101: Standard weekday transaction volume. All features match training distribution (PSI < 0.05).',
          driftBatchDesc: 'Batch 102 (Black Friday Surge): Covariate drift detected in transaction_amount (+190% mean shift) and location_risk_score. Model accuracy predicted to drop by ~14.2%.',
          schemaErrorDesc: 'Batch 103 (Mobile SDK Upgrade Bug): Null values in credit_score and negative values in transaction_amount. 24 contract violations flagged.',
        },
      },
      normalBatch: fraud.normalBatch,
      driftBatch: fraud.driftBatch,
      corruptBatch: fraud.corruptBatch,
    },

    churn: {
      scenario: {
        id: 'customer_churn',
        name: 'Enterprise Customer Churn Predictor',
        domain: 'SaaS & Telecom ML',
        targetModel: 'RandomForest Churn Predictor v1.8',
        description: 'Detects distribution drift following pricing plan updates and customer support ticket spikes.',
        schemas: churn.schemas,
        baselineData: churn.baseline,
        currentBatchData: churn.driftBatch,
        scenarioNotes: {
          normalBatchDesc: 'Batch 401: Normal monthly billing cycle data. Stable charges and support ticket counts.',
          driftBatchDesc: 'Batch 402 (Price Hike Impact): Monthly charges shifted from $64 to $108. Support complaints tripled. Critical PSI = 0.381.',
          schemaErrorDesc: 'Batch 403 (Billing System Outage): 10% null tenure_months and negative support ticket numbers.',
        },
      },
      normalBatch: churn.normalBatch,
      driftBatch: churn.driftBatch,
      corruptBatch: churn.corruptBatch,
    },

    health: {
      scenario: {
        id: 'icu_risk',
        name: 'ICU Patient Vital Signs Risk Engine',
        domain: 'Healthcare & Clinical ML',
        targetModel: 'LightGBM ICU Deterioration Risk v3.1',
        description: 'Continuous validation pipeline for hospital bedside vital sign sensors, detecting calibration drift and missingness.',
        schemas: health.schemas,
        baselineData: health.baseline,
        currentBatchData: health.driftBatch,
        scenarioNotes: {
          normalBatchDesc: 'Telemetry Batch 801: Calibrated ICU sensors, normal SPO2 and glucose readings.',
          driftBatchDesc: 'Telemetry Batch 802 (Sensor Calibration Drift): Glucose glucometers miscalibrated by +42 mg/dL across ICU ward 4. KS-statistic D = 0.412.',
          schemaErrorDesc: 'Telemetry Batch 803 (Cable Disconnection): SPO2 pulse oximeter missingness increased to 14.2%, exceeding non-null contract rules.',
        },
      },
      normalBatch: health.normalBatch,
      driftBatch: health.driftBatch,
      corruptBatch: health.corruptBatch,
    },
  };
}
