/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { InputControlPanel } from './components/InputControlPanel';
import { DataValidationReport } from './components/DataValidationReport';
import { DataDriftDashboard } from './components/DataDriftDashboard';
import { ContinuousStreamSimulator } from './components/ContinuousStreamSimulator';
import { CollegeDefenseGuide } from './components/CollegeDefenseGuide';
import { CodeGenerator } from './components/CodeGenerator';
import { AiDriftDiagnosticModal } from './components/AiDriftDiagnosticModal';

import { getPresetScenarios } from './data/presetScenarios';
import { evaluateSchemaValidation, analyzeFullDataDrift } from './utils/statistics';
import { DataRecord, FeatureSchema, SchemaViolation } from './types/pipeline';

export default function App() {
  const [activeTab, setActiveTab] = useState<'playground' | 'stream' | 'defense' | 'code'>('playground');
  const [scenarioKey, setScenarioKey] = useState<'fraud' | 'churn' | 'health'>('fraud');
  const [batchCondition, setBatchCondition] = useState<'normal' | 'drift' | 'corrupt'>('drift');

  // Live Modifiers
  const [meanShiftPct, setMeanShiftPct] = useState<number>(0);
  const [nullInjectPct, setNullInjectPct] = useState<number>(0);

  // Thresholds
  const [ksPValueThreshold, setKsPValueThreshold] = useState<number>(0.05);
  const [psiWarningThreshold, setPsiWarningThreshold] = useState<number>(0.10);
  const [psiCriticalThreshold, setPsiCriticalThreshold] = useState<number>(0.25);

  // Custom Uploaded Dataset Override
  const [customCsv, setCustomCsv] = useState<{ name: string; data: DataRecord[] } | null>(null);

  // Auto-fixed records memory
  const [imputedFixes, setImputedFixes] = useState<Record<string, boolean>>({});

  // AI Diagnostic Modal state
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);

  // All preset scenario datasets
  const allScenarios = useMemo(() => getPresetScenarios(), []);
  const activeScenarioObj = allScenarios[scenarioKey];
  const currentScenario = activeScenarioObj.scenario;

  // Derive active baseline & operational current batch
  const baselineData = currentScenario.baselineData;

  const rawCurrentBatchData = useMemo(() => {
    if (customCsv) return customCsv.data;
    if (batchCondition === 'normal') return activeScenarioObj.normalBatch;
    if (batchCondition === 'drift') return activeScenarioObj.driftBatch;
    return activeScenarioObj.corruptBatch;
  }, [customCsv, batchCondition, activeScenarioObj]);

  // Apply live modifiers (Mean Shift % & Null Injection %)
  const processedCurrentBatchData = useMemo(() => {
    return rawCurrentBatchData.map((row, idx) => {
      const newRow: DataRecord = { ...row };

      currentScenario.schemas.forEach((schema) => {
        const val = newRow[schema.name];

        // Apply Mean Shift if numerical
        if (schema.type === 'numerical' && typeof val === 'number' && meanShiftPct !== 0) {
          const factor = 1 + meanShiftPct / 100;
          newRow[schema.name] = Number((val * factor).toFixed(2));
        }

        // Apply Null Injection
        if (nullInjectPct > 0 && Math.random() * 100 < nullInjectPct) {
          newRow[schema.name] = null;
        }

        // Apply Imputation if Auto-Fix was clicked for this feature
        if (imputedFixes[schema.name]) {
          if (val === null || val === undefined) {
            newRow[schema.name] = schema.type === 'numerical' ? 50 : 'DEFAULT_TOKEN';
          }
        }
      });

      return newRow;
    });
  }, [rawCurrentBatchData, currentScenario.schemas, meanShiftPct, nullInjectPct, imputedFixes]);

  // Execute Data Validation Engine (Output 1)
  const validationSummary = useMemo(() => {
    return evaluateSchemaValidation(currentScenario.schemas, processedCurrentBatchData);
  }, [currentScenario.schemas, processedCurrentBatchData]);

  // Execute Data Drift Detection Engine (Output 2)
  const driftAnalysis = useMemo(() => {
    return analyzeFullDataDrift(currentScenario.schemas, baselineData, processedCurrentBatchData);
  }, [currentScenario.schemas, baselineData, processedCurrentBatchData]);

  // Handle Auto-Fix action
  const handleApplyAutoFix = (v: SchemaViolation) => {
    setImputedFixes((prev) => ({ ...prev, [v.featureName]: true }));
  };

  // Handle Custom CSV upload
  const handleCustomCsvLoaded = (name: string, data: DataRecord[]) => {
    setCustomCsv({ name, data });
  };

  // Reset inputs
  const handleResetInputs = () => {
    setMeanShiftPct(0);
    setNullInjectPct(0);
    setCustomCsv(null);
    setImputedFixes({});
  };

  // Export Audit Report (Print / JSON)
  const handleExportReport = () => {
    const reportObj = {
      title: 'Enterprise ML Continuous Data Drift & Validation Audit Report',
      timestamp: new Date().toISOString(),
      datasetName: currentScenario.name,
      domain: currentScenario.domain,
      validationHealthScore: validationSummary.healthScore,
      violationsCount: validationSummary.failedRulesCount,
      averagePsiScore: driftAnalysis.summary.averagePsi,
      maxKsStatistic: driftAnalysis.summary.maxKsStatistic,
      driftStatus: driftAnalysis.summary.overallStatus,
      violations: validationSummary.violations,
      driftResults: driftAnalysis.featureResults,
    };

    const blob = new Blob([JSON.stringify(reportObj, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `data_drift_audit_report_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Top Header Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAiDiagnostic={() => setIsAiModalOpen(true)}
        onExportReport={handleExportReport}
        isAiLoading={false}
        datasetName={customCsv ? customCsv.name : currentScenario.name}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* VIEW 1: PIPELINE PLAYGROUND (INPUTS -> PIPELINE -> OUTPUTS) */}
        {activeTab === 'playground' && (
          <div className="animate-fadeIn">
            {/* Input & Scenario Control Panel */}
            <InputControlPanel
              scenarioKey={scenarioKey}
              onSelectScenario={(key) => {
                setScenarioKey(key);
                setCustomCsv(null);
                setImputedFixes({});
              }}
              batchType={batchCondition}
              onSelectBatchType={(type) => {
                setBatchCondition(type);
                setCustomCsv(null);
              }}
              meanShiftPct={meanShiftPct}
              setMeanShiftPct={setMeanShiftPct}
              nullInjectPct={nullInjectPct}
              setNullInjectPct={setNullInjectPct}
              ksPValueThreshold={ksPValueThreshold}
              setKsPValueThreshold={setKsPValueThreshold}
              psiWarningThreshold={psiWarningThreshold}
              setPsiWarningThreshold={setPsiWarningThreshold}
              psiCriticalThreshold={psiCriticalThreshold}
              setPsiCriticalThreshold={setPsiCriticalThreshold}
              currentScenario={currentScenario}
              onCustomCsvLoaded={handleCustomCsvLoaded}
              onResetToDefaults={handleResetInputs}
            />

            {/* Pipeline Execution Banner */}
            <div className="bg-indigo-950/40 border border-indigo-800/40 rounded-xl p-3 mb-6 flex items-center justify-between text-xs text-indigo-200">
              <span className="font-mono flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                Pipeline Executed on {processedCurrentBatchData.length} records vs {baselineData.length} baseline records.
              </span>
              <span className="text-[11px] text-slate-400">
                Calculations: KS-Test | PSI | Wasserstein | Schema Contract
              </span>
            </div>

            {/* OUTPUT 1: Schema Contract Data Validation Report */}
            <DataValidationReport
              validationSummary={validationSummary}
              onApplyAutoFix={handleApplyAutoFix}
            />

            {/* OUTPUT 2: Statistical Data Drift Detection Dashboard */}
            <DataDriftDashboard
              driftResults={driftAnalysis.featureResults}
              overallSummary={driftAnalysis.summary}
              ksPValueThreshold={ksPValueThreshold}
              psiWarningThreshold={psiWarningThreshold}
              psiCriticalThreshold={psiCriticalThreshold}
            />
          </div>
        )}

        {/* VIEW 2: CONTINUOUS 30-DAY STREAM SIMULATOR */}
        {activeTab === 'stream' && (
          <div className="animate-fadeIn">
            <ContinuousStreamSimulator
              featureNames={currentScenario.schemas.map((s) => s.name)}
            />
          </div>
        )}

        {/* VIEW 3: COLLEGE DEFENSE & VIVA GUIDE */}
        {activeTab === 'defense' && (
          <div className="animate-fadeIn">
            <CollegeDefenseGuide />
          </div>
        )}

        {/* VIEW 4: CODE GENERATOR */}
        {activeTab === 'code' && (
          <div className="animate-fadeIn">
            <CodeGenerator
              schemas={currentScenario.schemas}
              ksPValueThreshold={ksPValueThreshold}
              psiWarningThreshold={psiWarningThreshold}
              psiCriticalThreshold={psiCriticalThreshold}
              datasetName={currentScenario.name}
            />
          </div>
        )}
      </main>

      {/* AI Diagnostic Modal */}
      <AiDriftDiagnosticModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        datasetName={currentScenario.name}
        validationSummary={validationSummary}
        driftResults={driftAnalysis.featureResults}
      />
    </div>
  );
}
