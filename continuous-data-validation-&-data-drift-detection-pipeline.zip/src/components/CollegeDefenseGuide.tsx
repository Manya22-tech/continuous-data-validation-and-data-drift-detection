import React, { useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  GitMerge,
  Binary,
  HelpCircle,
  MessageSquare,
  CheckCircle2,
  Sparkles,
  ChevronRight,
  ShieldAlert,
  Cpu,
  Layers,
  Zap,
  ArrowRight,
  FileCode,
  Lightbulb,
} from 'lucide-react';

export const CollegeDefenseGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'architecture' | 'math' | 'script' | 'viva'>('overview');
  const [expandedQaIndex, setExpandedQaIndex] = useState<number | null>(0);

  const vivaQuestions = [
    {
      q: '1. What is Data Drift (Covariate Shift) and how is it different from Concept Drift?',
      a: 'Data Drift (Covariate Shift) occurs when the statistical distribution of the input features P(X) changes over time, while the conditional probability P(Y|X) remains unchanged. For example, during a holiday season, customer income or transaction amounts shift upwards. In contrast, Concept Drift occurs when the underlying relationship between inputs and targets P(Y|X) changes (e.g., macroeconomic inflation changing what defines a default risk).',
      tip: 'Highlight to examiners that this pipeline detects Data Drift P(X) continuously before model predictions degrade.',
    },
    {
      q: '2. Why is Population Stability Index (PSI) used in production pipelines alongside the Kolmogorov-Smirnov (KS) test?',
      a: 'PSI measures the overall shift in distribution between a baseline dataset and a target dataset across quantile or equal-width bins. PSI provides an intuitive, scale-invariant score with standardized industry boundaries (PSI < 0.10: Stable, 0.10 ≤ PSI < 0.25: Moderate shift, PSI ≥ 0.25: Severe shift). The KS-Test calculates the maximum vertical distance between empirical CDFs and provides a p-value. Using both guarantees sensitivity to both small regional shifts and general distribution movements.',
      tip: 'State the PSI formula: PSI = Σ (Actual % - Expected %) * ln(Actual % / Expected %).',
    },
    {
      q: '3. How does the Data Validation (Schema Contract) stage protect downstream Machine Learning models?',
      a: 'In enterprise pipelines, upstream API updates or database migrations frequently introduce missing columns, unexpected nulls, or type mismatches. If unhandled, these corrupt payload records crash model pipelines or cause garbage-in-garbage-out silent failures. The Schema Contract enforces strict assertions on data types, null percentages, min/max bounds, and allowed categorical tokens prior to inference scoring.',
      tip: 'Show professors the "Apply Fix" auto-imputation button in Output 1 during your presentation.',
    },
    {
      q: '4. What automated remediation actions are triggered when severe drift is detected?',
      a: 'When PSI crosses the critical threshold (≥ 0.25) or schema contract failures spike: 1) The pipeline logs an incident to PagerDuty/Kafka. 2) Ingested records are quarantined in isolated storage. 3) An automated model retraining pipeline is triggered via Airflow/Kubeflow using the newly drifted dataset window.',
      tip: 'Mention that silent model degradation costs enterprises millions, making automated alerting critical.',
    },
    {
      q: '5. What is Wasserstein Distance (Earth Mover’s Distance) and why is it included in your pipeline?',
      a: 'Wasserstein distance measures the minimal "work" required to transform one probability distribution into another. Unlike KL-divergence, Wasserstein distance is symmetric, smooth, non-infinite for non-overlapping distributions, and provides a continuous metric even when feature bins have zero counts.',
      tip: 'Use the analogy of moving piles of dirt from one shape into another.',
    },
    {
      q: '6. How does your pipeline handle unseen categorical values in production batches?',
      a: 'When an unallowed category is ingested (e.g. "SmartWatch_NFC" in device_type), the Chi-Square test flags categorical drift, and the schema validator flags an "UNALLOWED_CATEGORY" violation. The pipeline automatically maps novel categories to an "OTHER" token or triggers categorical encoder updates.',
      tip: 'Point to the device_type feature in the Credit Card Fraud scenario.',
    },
    {
      q: '7. How do you choose the binning strategy for PSI calculation?',
      a: 'PSI can use Equal-Width Binning (dividing range into N equal intervals) or Equal-Frequency Quantile Binning (dividing baseline into 10 deciles with ~10% data per bin). Equal-frequency binning is preferred for skewed distributions to ensure sufficient counts in each bin.',
      tip: 'Mention that a small epsilon (0.0001) smoothing factor is added to avoid division-by-zero or ln(0).',
    },
    {
      q: '8. How does this project scale to Big Data enterprise systems processing terabytes daily?',
      a: 'In real enterprise production, this architecture is implemented using Apache Spark / PySpark or Great Expectations running on distributed clusters (Databricks / AWS EMR). The statistical computations (bin counts, histograms, quantiles) map efficiently to distributed MapReduce primitives.',
      tip: 'Refer examiners to the "PySpark / GE Code Generator" tab in your project.',
    },
  ];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl text-white mb-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
            <GraduationCap className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <span>College Viva & Project Defense Master Guide</span>
              <span className="text-xs bg-amber-500/10 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-mono font-bold">
                Presentation Ready
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Complete guide for explaining this continuous data validation & drift pipeline project to your college professors, guides, and examiners.
            </p>
          </div>
        </div>
      </div>

      {/* Defense Navigation Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-3 mb-6 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition-all shrink-0 ${
            activeTab === 'overview'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-950 text-slate-400 hover:text-white'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>1. Project Overview & Problem Statement</span>
        </button>

        <button
          onClick={() => setActiveTab('architecture')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition-all shrink-0 ${
            activeTab === 'architecture'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-950 text-slate-400 hover:text-white'
          }`}
        >
          <GitMerge className="w-4 h-4" />
          <span>2. End-to-End Pipeline Architecture</span>
        </button>

        <button
          onClick={() => setActiveTab('math')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition-all shrink-0 ${
            activeTab === 'math'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-950 text-slate-400 hover:text-white'
          }`}
        >
          <Binary className="w-4 h-4" />
          <span>3. Mathematical Formulas & Bounds</span>
        </button>

        <button
          onClick={() => setActiveTab('script')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition-all shrink-0 ${
            activeTab === 'script'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-950 text-slate-400 hover:text-white'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>4. Step-by-Step Presentation Script</span>
        </button>

        <button
          onClick={() => setActiveTab('viva')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium transition-all shrink-0 ${
            activeTab === 'viva'
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-950 text-slate-400 hover:text-white'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>5. Examiner Viva Q&A (Masterclass)</span>
        </button>
      </div>

      {/* Tab 1: Project Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
            <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              What is this project and why is it important in Enterprise ML?
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              When Machine Learning models are deployed into production enterprise environments (e.g., Credit Card Fraud Detection, Telecom Churn Prediction, Hospital ICU Risk Monitoring), they are trained on historical offline datasets. Over time, incoming production data changes due to seasonal trends, market fluctuations, or upstream software API updates.
            </p>
            <p className="text-xs text-slate-300 leading-relaxed">
              Without continuous monitoring, ML models experience <strong className="text-amber-400">silent failure</strong> — they continue serving predictions, but their accuracy degrades catastrophically. This project implements an automated enterprise-grade pipeline that performs <strong className="text-indigo-300">Continuous Data Validation</strong> (checking schema contracts and data types) and <strong className="text-indigo-300">Data Drift Detection</strong> (calculating statistical shifts between baseline training data and operational batches) before predictions fail.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
              <div className="w-8 h-8 rounded-lg bg-rose-500/20 border border-rose-500/40 flex items-center justify-center mb-3">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
              </div>
              <h4 className="text-xs font-bold text-slate-200">The Problem</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                Models fail silently in production due to Covariate Shift and corrupted payload schema updates without raising traditional software runtime exceptions.
              </p>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center mb-3">
                <Cpu className="w-4 h-4 text-indigo-400" />
              </div>
              <h4 className="text-xs font-bold text-slate-200">Our Solution</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                A dual-stage pipeline combining Great Expectations schema contract validation with rigorous statistical test suites (KS-Test, PSI, Wasserstein Distance).
              </p>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mb-3">
                <Zap className="w-4 h-4 text-emerald-400" />
              </div>
              <h4 className="text-xs font-bold text-slate-200">Business Impact</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                Automated quarantine of corrupted batches and automated trigger of model retraining pipelines before financial or clinical damage occurs.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Architecture */}
      {activeTab === 'architecture' && (
        <div className="space-y-6 animate-fadeIn">
          <h3 className="text-sm font-bold text-amber-300">End-to-End Enterprise Dataflow Architecture</h3>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
            {/* Step 1 */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 relative">
              <span className="text-[10px] text-indigo-400 font-mono font-bold">STAGE 1</span>
              <h4 className="font-bold text-slate-100">Data Ingestion Payload</h4>
              <p className="text-[11px] text-slate-400">
                Operational inference payload ingested from REST API, Kafka topic, or microservice feed.
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] text-indigo-400 font-mono font-bold">STAGE 2</span>
              <h4 className="font-bold text-slate-100">Schema Contract Validator</h4>
              <p className="text-[11px] text-slate-400">
                Validates null percentages, allowed categories, data types, and min/max domain bounds.
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] text-indigo-400 font-mono font-bold">STAGE 3</span>
              <h4 className="font-bold text-slate-100">Statistical Drift Engine</h4>
              <p className="text-[11px] text-slate-400">
                Calculates KS-Test p-values, PSI decile terms, Wasserstein distance, and Chi-Square stats.
              </p>
            </div>

            {/* Step 4 */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] text-indigo-400 font-mono font-bold">STAGE 4</span>
              <h4 className="font-bold text-slate-100">Health Scoring & Alerting</h4>
              <p className="text-[11px] text-slate-400">
                Computes overall 0-100% Health Score and evaluates PSI thresholds (0.10 warning, 0.25 action).
              </p>
            </div>

            {/* Step 5 */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] text-amber-400 font-mono font-bold">STAGE 5</span>
              <h4 className="font-bold text-slate-100">Action & Retraining</h4>
              <p className="text-[11px] text-slate-400">
                Quarantines bad data, triggers Airflow DAG for model retraining, or auto-imputes missing values.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Mathematical Formulas */}
      {activeTab === 'math' && (
        <div className="space-y-6 animate-fadeIn">
          <h3 className="text-sm font-bold text-amber-300">Mathematical Formulations & Statistical Tests</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* PSI Card */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-indigo-300 text-xs">1. Population Stability Index (PSI)</h4>
                <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded font-mono">
                  Continuous Metric
                </span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg font-mono text-xs text-amber-300 my-2 text-center border border-slate-800">
                PSI = &sum;<sub>i=1..N</sub> [ ( Actual<sub>i</sub>% - Expected<sub>i</sub>% ) &times; ln( Actual<sub>i</sub>% / Expected<sub>i</sub>% ) ]
              </div>
              <ul className="text-[11px] text-slate-400 space-y-1 list-disc pl-4">
                <li><strong className="text-emerald-400">PSI &lt; 0.10:</strong> No significant distribution change (Stable).</li>
                <li><strong className="text-amber-400">0.10 &le; PSI &lt; 0.25:</strong> Moderate distribution drift (Warning).</li>
                <li><strong className="text-rose-400">PSI &ge; 0.25:</strong> Significant distribution drift (Action required).</li>
              </ul>
            </div>

            {/* KS Test Card */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-indigo-300 text-xs">2. Kolmogorov-Smirnov (KS) Test</h4>
                <span className="text-[10px] bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded font-mono">
                  Hypothesis Testing
                </span>
              </div>
              <div className="bg-slate-900 p-3 rounded-lg font-mono text-xs text-cyan-300 my-2 text-center border border-slate-800">
                D = sup<sub>x</sub> | F<sub>Baseline</sub>(x) - F<sub>Current</sub>(x) |
              </div>
              <p className="text-[11px] text-slate-400">
                Calculates the maximum vertical distance <strong className="text-slate-200">D</strong> between empirical Cumulative Distribution Functions (CDFs). Reject null hypothesis if p-value &lt; 0.05.
              </p>
            </div>

            {/* Wasserstein Distance */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h4 className="font-bold text-indigo-300 text-xs">3. Wasserstein Distance (1D Earth Mover’s)</h4>
              <div className="bg-slate-900 p-3 rounded-lg font-mono text-xs text-purple-300 my-2 text-center border border-slate-800">
                W(u, v) = &int; | U(x) - V(x) | dx
              </div>
              <p className="text-[11px] text-slate-400">
                Measures the minimum energy required to transform one empirical distribution into another. Robust against binning boundaries.
              </p>
            </div>

            {/* Chi-Square */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <h4 className="font-bold text-indigo-300 text-xs">4. Categorical Chi-Square Goodness-of-Fit</h4>
              <div className="bg-slate-900 p-3 rounded-lg font-mono text-xs text-emerald-300 my-2 text-center border border-slate-800">
                &chi;&sup2; = &sum; [ ( Observed - Expected )&sup2; / Expected ]
              </div>
              <p className="text-[11px] text-slate-400">
                Evaluates categorical frequency shifts and detects novel unseen categorical tokens in operational batches.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Script */}
      {activeTab === 'script' && (
        <div className="space-y-4 animate-fadeIn">
          <h3 className="text-sm font-bold text-amber-300">Step-by-Step Viva Presentation Script ("What to say and click")</h3>

          <div className="space-y-3 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <span className="text-amber-400 font-bold font-mono">STEP 1: Introduction (30 seconds)</span>
              <p className="text-slate-300 mt-1">
                "Respected Professors, today we present our project on <strong>Continuous Data Validation and Data Drift Detection Pipelines for Enterprise ML Systems</strong>. In production ML systems, models fail silently when data distributions shift. Our system continuously monitors incoming data streams against a reference baseline dataset."
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <span className="text-indigo-400 font-bold font-mono">STEP 2: Demonstrate Normal Operation (Click 'Stable Batch')</span>
              <p className="text-slate-300 mt-1">
                "Here, we select our Credit Card Fraud baseline. Under normal operation, Output 1 shows a 100% Data Health Score, and Output 2 shows an Average PSI of 0.02. No statistical drift is present."
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <span className="text-amber-400 font-bold font-mono">STEP 3: Demonstrate Covariate Drift (Click 'Covariate Data Drift')</span>
              <p className="text-slate-300 mt-1">
                "Now, we simulate a holiday shopping surge batch. Notice how the transaction_amount mean shifts from $65 to $195. Our KS-Test calculates a D-statistic of 0.41, and the Population Stability Index crosses 0.38 (Severe Drift). Point to the overlay chart to show the exact histogram bin shift."
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <span className="text-rose-400 font-bold font-mono">STEP 4: Demonstrate Schema Failure (Click 'Schema Corruption')</span>
              <p className="text-slate-300 mt-1">
                "Next, we simulate an upstream mobile SDK bug introducing null values and negative transaction amounts. Output 1 immediately flags 24 schema violations and drops the Health Score to 58%. Clicking 'Apply Fix' auto-imputes missing values with baseline medians."
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
              <span className="text-cyan-400 font-bold font-mono">STEP 5: Demonstrate 30-Day Stream & Code Export</span>
              <p className="text-slate-300 mt-1">
                "Finally, in the 30-Day Stream tab, we show how our continuous pipeline logs temporal drift accumulation over 30 days, firing an automated retraining trigger on Day 21. We also export PySpark and Great Expectations python scripts."
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Viva Q&A */}
      {activeTab === 'viva' && (
        <div className="space-y-4 animate-fadeIn">
          <h3 className="text-sm font-bold text-amber-300">Examiner Viva Q&A Masterclass (15 Key Questions & Answers)</h3>

          <div className="space-y-3">
            {vivaQuestions.map((item, idx) => {
              const isExpanded = expandedQaIndex === idx;
              return (
                <div
                  key={idx}
                  className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden transition-all"
                >
                  <button
                    onClick={() => setExpandedQaIndex(isExpanded ? null : idx)}
                    className="w-full text-left p-4 flex items-center justify-between gap-3 hover:bg-slate-900/60 transition-colors"
                  >
                    <span className="text-xs font-bold text-slate-200 flex items-center gap-2">
                      <HelpCircle className="w-4 h-4 text-amber-400 shrink-0" />
                      {item.q}
                    </span>
                    <ChevronRight
                      className={`w-4 h-4 text-slate-500 transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                    />
                  </button>

                  {isExpanded && (
                    <div className="p-4 pt-0 border-t border-slate-800/80 bg-slate-900/40 text-xs space-y-2">
                      <p className="text-slate-300 leading-relaxed mt-2">{item.a}</p>
                      <div className="p-2.5 rounded-lg bg-indigo-950/40 border border-indigo-800/40 flex items-start gap-2 text-indigo-200 text-[11px]">
                        <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <div>
                          <strong>Pro Tip for Presentation:</strong> {item.tip}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
