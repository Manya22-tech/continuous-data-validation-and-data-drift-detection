import React, { useState } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Search,
  Filter,
  Wrench,
  HelpCircle,
  Check,
} from 'lucide-react';
import { ValidationSummary, SchemaViolation } from '../types/pipeline';

interface DataValidationReportProps {
  validationSummary: ValidationSummary;
  onApplyAutoFix?: (violation: SchemaViolation) => void;
}

export const DataValidationReport: React.FC<DataValidationReportProps> = ({
  validationSummary,
  onApplyAutoFix,
}) => {
  const [filterSeverity, setFilterSeverity] = useState<'ALL' | 'CRITICAL' | 'WARNING'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [appliedFixes, setAppliedFixes] = useState<Record<string, boolean>>({});

  const filteredViolations = validationSummary.violations.filter((v) => {
    const matchesSeverity = filterSeverity === 'ALL' || v.severity === filterSeverity;
    const matchesSearch =
      v.featureName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSeverity && matchesSearch;
  });

  const handleFixClick = (v: SchemaViolation) => {
    setAppliedFixes((prev) => ({ ...prev, [v.id]: true }));
    if (onApplyAutoFix) onApplyAutoFix(v);
  };

  const getHealthBadge = (score: number) => {
    if (score >= 90) return { label: 'EXCELLENT HEALTH', bg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' };
    if (score >= 70) return { label: 'MODERATE RISK', bg: 'bg-amber-500/10 text-amber-400 border-amber-500/30' };
    return { label: 'CRITICAL CORRUPTION', bg: 'bg-rose-500/10 text-rose-400 border-rose-500/30' };
  };

  const healthBadge = getHealthBadge(validationSummary.healthScore);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl text-white mb-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>Output 1: Data Validation & Schema Contract Report</span>
              <span className={`text-xs px-2 py-0.5 rounded border font-mono font-semibold ${healthBadge.bg}`}>
                {healthBadge.label}
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Evaluates ingestion payload against Great Expectations-style structural constraints (Nullability, Domain Boundaries, Column Types).
            </p>
          </div>
        </div>
      </div>

      {/* Summary KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        {/* Metric 1: Health Score */}
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Schema Health Score</span>
            <ShieldCheck className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span
              className={`text-2xl font-extrabold ${
                validationSummary.healthScore >= 90
                  ? 'text-emerald-400'
                  : validationSummary.healthScore >= 70
                  ? 'text-amber-400'
                  : 'text-rose-400'
              }`}
            >
              {validationSummary.healthScore}%
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Passed Rules Rate</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2.5 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                validationSummary.healthScore >= 90
                  ? 'bg-emerald-400'
                  : validationSummary.healthScore >= 70
                  ? 'bg-amber-400'
                  : 'bg-rose-500'
              }`}
              style={{ width: `${validationSummary.healthScore}%` }}
            />
          </div>
        </div>

        {/* Metric 2: Total Records Monitored */}
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5">
          <div className="text-slate-400 text-xs mb-1">Batch Size Checked</div>
          <div className="text-2xl font-extrabold text-slate-100 font-mono">
            {validationSummary.totalRecordsChecked.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">
            Across {validationSummary.totalFeaturesChecked} feature columns
          </div>
        </div>

        {/* Metric 3: Passed Rules */}
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Passed Contract Rules</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono">
            {validationSummary.passedRulesCount}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Contract assertions met</div>
        </div>

        {/* Metric 4: Violated Contract Rules */}
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>Contract Violations</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-extrabold text-rose-400 font-mono">
            {validationSummary.failedRulesCount}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Failed contract assertions</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-4">
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search feature or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs w-full sm:w-auto">
          <span className="text-slate-500 px-2 flex items-center gap-1 text-[11px]">
            <Filter className="w-3 h-3" /> Severity:
          </span>
          <button
            onClick={() => setFilterSeverity('ALL')}
            className={`px-2.5 py-1 rounded text-xs transition-all ${
              filterSeverity === 'ALL' ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            All ({validationSummary.violations.length})
          </button>
          <button
            onClick={() => setFilterSeverity('CRITICAL')}
            className={`px-2.5 py-1 rounded text-xs transition-all ${
              filterSeverity === 'CRITICAL' ? 'bg-rose-500/20 text-rose-300 font-semibold border border-rose-500/30' : 'text-slate-400 hover:text-white'
            }`}
          >
            Critical ({validationSummary.violations.filter((v) => v.severity === 'CRITICAL').length})
          </button>
          <button
            onClick={() => setFilterSeverity('WARNING')}
            className={`px-2.5 py-1 rounded text-xs transition-all ${
              filterSeverity === 'WARNING' ? 'bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30' : 'text-slate-400 hover:text-white'
            }`}
          >
            Warning ({validationSummary.violations.filter((v) => v.severity === 'WARNING').length})
          </button>
        </div>
      </div>

      {/* Violations Table */}
      {filteredViolations.length === 0 ? (
        <div className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-8 text-center">
          <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
          <h4 className="text-sm font-bold text-slate-200">No Schema Violations Detected</h4>
          <p className="text-xs text-slate-400 mt-1">
            All feature payload checks satisfied configured data type, domain range, and nullability assertions.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 font-mono text-[11px]">
                <th className="p-3">Feature Column</th>
                <th className="p-3">Violation Category</th>
                <th className="p-3">Severity</th>
                <th className="p-3">Affected Rows</th>
                <th className="p-3">Issue Details</th>
                <th className="p-3 text-right">Automated Fix</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredViolations.map((v) => {
                const isFixed = appliedFixes[v.id];
                return (
                  <tr key={v.id} className="hover:bg-slate-900/50 transition-colors">
                    <td className="p-3 font-bold font-mono text-indigo-300">{v.featureName}</td>
                    <td className="p-3 font-mono text-[11px] text-slate-400">{v.violationType}</td>
                    <td className="p-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border ${
                          v.severity === 'CRITICAL'
                            ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                            : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                        }`}
                      >
                        {v.severity === 'CRITICAL' ? (
                          <XCircle className="w-3 h-3" />
                        ) : (
                          <AlertTriangle className="w-3 h-3" />
                        )}
                        {v.severity}
                      </span>
                    </td>
                    <td className="p-3 font-mono">
                      <span className="text-slate-100 font-bold">{v.affectedCount}</span>
                      <span className="text-slate-500 text-[10px] ml-1">({v.affectedPercentage}%)</span>
                    </td>
                    <td className="p-3 max-w-xs">
                      <p className="text-slate-200">{v.description}</p>
                      <p className="text-[10px] text-indigo-300/80 mt-0.5 flex items-center gap-1">
                        <HelpCircle className="w-3 h-3 shrink-0" />
                        <span>Fix: {v.suggestedFix}</span>
                      </p>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() => handleFixClick(v)}
                        disabled={isFixed}
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs transition-all ${
                          isFixed
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 cursor-default'
                            : 'bg-indigo-600 hover:bg-indigo-500 text-white font-medium shadow-sm'
                        }`}
                      >
                        {isFixed ? (
                          <>
                            <Check className="w-3 h-3" />
                            <span>Imputed</span>
                          </>
                        ) : (
                          <>
                            <Wrench className="w-3 h-3" />
                            <span>Apply Fix</span>
                          </>
                        )}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
