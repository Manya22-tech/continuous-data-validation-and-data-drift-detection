import React from 'react';
import {
  Activity,
  ShieldCheck,
  TrendingUp,
  GraduationCap,
  Code2,
  Download,
  PlayCircle,
  Cpu,
  Layers,
} from 'lucide-react';

interface NavbarProps {
  activeTab: 'playground' | 'stream' | 'defense' | 'code';
  setActiveTab: (tab: 'playground' | 'stream' | 'defense' | 'code') => void;
  onOpenAiDiagnostic: () => void;
  onExportReport: () => void;
  isAiLoading: boolean;
  datasetName: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAiDiagnostic,
  onExportReport,
  isAiLoading,
  datasetName,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Activity className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-white tracking-wide">
                  Data Drift & Validation Pipeline
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Enterprise ML Engine v2.4
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-1">
                <Layers className="w-3 h-3 text-slate-500" />
                <span>Active Target:</span>
                <span className="text-indigo-300 font-medium">{datasetName}</span>
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('playground')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'playground'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Pipeline Playground</span>
            </button>

            <button
              onClick={() => setActiveTab('stream')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'stream'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>30-Day Continuous Stream</span>
            </button>

            <button
              onClick={() => setActiveTab('defense')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'defense'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/30'
                  : 'text-amber-400 hover:text-amber-300 hover:bg-slate-800/60'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>College Viva & Defense Guide</span>
            </button>

            <button
              onClick={() => setActiveTab('code')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'code'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>PySpark / GE Code</span>
            </button>
          </nav>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenAiDiagnostic}
              disabled={isAiLoading}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-semibold hover:from-purple-500 hover:to-indigo-500 transition-all shadow-md shadow-purple-600/20 border border-purple-400/30 disabled:opacity-50"
            >
              <Cpu className={`w-3.5 h-3.5 ${isAiLoading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">AI Root-Cause Diagnosis</span>
              <span className="sm:hidden">AI Fix</span>
            </button>

            <button
              onClick={onExportReport}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 text-xs font-medium transition-all border border-slate-700"
              title="Print / Save Audit Report"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Export Audit</span>
            </button>
          </div>
        </div>

        {/* Mobile Sub-Nav */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-800/80 text-xs">
          <button
            onClick={() => setActiveTab('playground')}
            className={`py-1 px-2 rounded ${activeTab === 'playground' ? 'text-indigo-400 font-bold bg-slate-800' : 'text-slate-400'}`}
          >
            Playground
          </button>
          <button
            onClick={() => setActiveTab('stream')}
            className={`py-1 px-2 rounded ${activeTab === 'stream' ? 'text-indigo-400 font-bold bg-slate-800' : 'text-slate-400'}`}
          >
            30-Day Stream
          </button>
          <button
            onClick={() => setActiveTab('defense')}
            className={`py-1 px-2 rounded ${activeTab === 'defense' ? 'text-amber-400 font-bold bg-amber-500/10 border border-amber-500/20' : 'text-amber-300'}`}
          >
            Viva Guide
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`py-1 px-2 rounded ${activeTab === 'code' ? 'text-indigo-400 font-bold bg-slate-800' : 'text-slate-400'}`}
          >
            Code
          </button>
        </div>
      </div>
    </header>
  );
};
