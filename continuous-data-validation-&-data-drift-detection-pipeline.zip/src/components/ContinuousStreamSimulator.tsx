import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Activity,
  AlertTriangle,
  BellRing,
  TrendingUp,
  Clock,
  ShieldAlert,
  Flame,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { TimeSeriesPoint } from '../types/pipeline';

interface ContinuousStreamSimulatorProps {
  featureNames: string[];
}

export const ContinuousStreamSimulator: React.FC<ContinuousStreamSimulatorProps> = ({
  featureNames,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentDay, setCurrentDay] = useState(1);
  const [streamSpeed, setStreamSpeed] = useState<number>(1000); // ms per day step

  // Generate realistic 30-day continuous drift timeline
  const generate30DaySeries = (): TimeSeriesPoint[] => {
    const points: TimeSeriesPoint[] = [];
    const top4Features = featureNames.slice(0, 4);

    for (let day = 1; day <= 30; day++) {
      const date = new Date(2026, 6, day);
      const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      // Simulate drift accumulation starting around Day 12
      let driftFactor = 0;
      if (day > 12) {
        driftFactor = (day - 12) * 0.022 + Math.random() * 0.03;
      }

      const featurePsiMap: Record<string, number> = {};
      let psiSum = 0;

      top4Features.forEach((feat, idx) => {
        const baseNoise = 0.02 + Math.random() * 0.02;
        // Feature 0 drifts heavily, Feature 1 drifts moderately, others remain lower
        const weight = idx === 0 ? 1.8 : idx === 1 ? 1.1 : 0.4;
        const psi = Number((baseNoise + driftFactor * weight).toFixed(4));
        featurePsiMap[feat] = psi;
        psiSum += psi;
      });

      const overallPsi = Number((psiSum / (top4Features.length || 1)).toFixed(4));
      const healthScore = Math.max(45, Math.round(100 - overallPsi * 140));
      const driftedCount = Object.values(featurePsiMap).filter((p) => p >= 0.10).length;

      let alertTriggered: string | undefined;
      if (day === 14) alertTriggered = 'WARNING: Feature 1 PSI crossed 0.10 threshold.';
      if (day === 21) alertTriggered = 'CRITICAL: Overall PSI crossed 0.25! Retraining workflow initiated.';
      if (day === 28) alertTriggered = 'AUTOMATED FIX: New model weights deployed. PSI normalizing.';

      points.push({
        day,
        dateStr,
        overallPsi,
        driftedFeatureCount: driftedCount,
        healthScore,
        featurePsiMap,
        alertTriggered,
      });
    }

    return points;
  };

  const [timeSeriesData] = useState<TimeSeriesPoint[]>(generate30DaySeries);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying) {
      timer = setInterval(() => {
        setCurrentDay((prev) => {
          if (prev >= 30) {
            setIsPlaying(false);
            return 30;
          }
          return prev + 1;
        });
      }, streamSpeed);
    }
    return () => clearInterval(timer);
  }, [isPlaying, streamSpeed]);

  const activePoint = timeSeriesData.find((p) => p.day === currentDay) || timeSeriesData[0];
  const chartVisibleData = timeSeriesData.slice(0, currentDay);

  const getHeatmapColor = (psi: number) => {
    if (psi >= 0.25) return 'bg-rose-500 text-white font-bold animate-pulse';
    if (psi >= 0.10) return 'bg-amber-500/80 text-slate-950 font-bold';
    if (psi >= 0.05) return 'bg-indigo-900/60 text-indigo-200';
    return 'bg-slate-900 text-slate-400';
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl text-white mb-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center">
            <Activity className="w-5 h-5 text-indigo-400 animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>Output 3: Continuous 30-Day Stream Simulator</span>
              <span className="text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded font-mono">
                Live Stream Ingestion
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Simulates automated daily batch ingestion over a 30-day window to track temporal drift buildup and automated trigger events.
            </p>
          </div>
        </div>

        {/* Stream Simulator Play/Pause Controls */}
        <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              isPlaying
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30'
                : 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 hover:bg-indigo-500'
            }`}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 fill-current" />
                <span>Pause Stream</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Play Simulation</span>
              </>
            )}
          </button>

          <button
            onClick={() => {
              setIsPlaying(false);
              setCurrentDay(1);
            }}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all"
            title="Reset to Day 1"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1 text-[11px] text-slate-400 border-l border-slate-800 pl-2">
            <span>Speed:</span>
            <button
              onClick={() => setStreamSpeed(1000)}
              className={`px-1.5 py-0.5 rounded font-mono ${streamSpeed === 1000 ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800'}`}
            >
              1x
            </button>
            <button
              onClick={() => setStreamSpeed(400)}
              className={`px-1.5 py-0.5 rounded font-mono ${streamSpeed === 400 ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800'}`}
            >
              2x
            </button>
          </div>
        </div>
      </div>

      {/* Day Scrubber Slider & Current Day Status */}
      <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 mb-6">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="font-semibold text-slate-200 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            Ingestion Day: <span className="font-mono text-indigo-300 font-bold text-sm">Day {currentDay}</span>
            <span className="text-slate-500 font-mono">({activePoint.dateStr})</span>
          </span>
          <div className="flex items-center gap-4 text-[11px] font-mono">
            <span>Overall PSI: <strong className={activePoint.overallPsi >= 0.25 ? 'text-rose-400' : 'text-emerald-400'}>{activePoint.overallPsi}</strong></span>
            <span>Health Score: <strong className="text-cyan-300">{activePoint.healthScore}%</strong></span>
          </div>
        </div>

        <input
          type="range"
          min="1"
          max="30"
          value={currentDay}
          onChange={(e) => {
            setIsPlaying(false);
            setCurrentDay(Number(e.target.value));
          }}
          className="w-full accent-indigo-500 bg-slate-800 h-2 rounded-lg cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
          <span>Day 1 (Baseline Ingest)</span>
          <span>Day 15 (Covariate Shift)</span>
          <span>Day 30 (Automated Normalization)</span>
        </div>
      </div>

      {/* Recharts Continuous Trend Line Chart */}
      <div className="mb-6">
        <h4 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-indigo-400" />
          30-Day Population Stability Index (PSI) Continuous Drift Timeline
        </h4>
        <div className="h-64 w-full bg-slate-950/60 p-3 rounded-xl border border-slate-800">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartVisibleData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.4} />
              <XAxis dataKey="day" stroke="#94a3b8" fontSize={10} tickLine={false} unit="d" />
              <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} domain={[0, 0.45]} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }} />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '5px' }} />
              <Line type="monotone" dataKey="overallPsi" name="Overall Avg PSI" stroke="#818cf8" strokeWidth={3} dot={false} />
              {featureNames.slice(0, 3).map((feat, idx) => {
                const colors = ['#f59e0b', '#22d3ee', '#ec4899'];
                return (
                  <Line
                    key={feat}
                    type="monotone"
                    dataKey={`featurePsiMap.${feat}`}
                    name={`PSI: ${feat}`}
                    stroke={colors[idx % colors.length]}
                    strokeWidth={1.5}
                    dot={false}
                  />
                );
              })}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 30-Day Feature Drift Heatmap */}
      <div className="mb-6">
        <h4 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-2">
          <Flame className="w-4 h-4 text-amber-400" />
          Feature-by-Day Drift Heatmap (Grid)
        </h4>
        <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950 p-3">
          <table className="w-full text-center border-collapse text-[10px] font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500">
                <th className="text-left p-2">Feature Name</th>
                {Array.from({ length: 30 }, (_, i) => i + 1).map((d) => (
                  <th key={d} className={`p-1 ${d === currentDay ? 'text-indigo-400 font-bold bg-slate-800/80 rounded' : ''}`}>
                    {d}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {featureNames.slice(0, 4).map((feat) => (
                <tr key={feat} className="border-b border-slate-900/60">
                  <td className="text-left p-2 font-bold text-slate-300 truncate max-w-[120px]">{feat}</td>
                  {timeSeriesData.map((pt) => {
                    const psi = pt.featurePsiMap[feat] || 0;
                    const isFuture = pt.day > currentDay;
                    return (
                      <td
                        key={pt.day}
                        className={`p-1 border border-slate-950/40 rounded ${
                          isFuture ? 'bg-slate-950/30 text-slate-700' : getHeatmapColor(psi)
                        }`}
                        title={`Day ${pt.day} - ${feat}: PSI = ${psi}`}
                      >
                        {isFuture ? '-' : psi.toFixed(2)}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Automated Event Trigger Stream Log */}
      <div>
        <h4 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-2">
          <BellRing className="w-4 h-4 text-cyan-400" />
          Automated Pipeline Alert & Incident Stream Log
        </h4>
        <div className="bg-slate-950/80 rounded-xl border border-slate-800 p-3 space-y-2 max-h-48 overflow-y-auto">
          {timeSeriesData
            .filter((p) => p.day <= currentDay && p.alertTriggered)
            .map((p) => (
              <div
                key={p.day}
                className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-start gap-2.5 text-xs animate-fadeIn"
              >
                <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-200 flex items-center gap-2">
                    <span>Day {p.day} Alert Trigger:</span>
                    <span className="text-[10px] text-slate-500 font-mono">({p.dateStr})</span>
                  </div>
                  <p className="text-slate-300 text-[11px] mt-0.5">{p.alertTriggered}</p>
                </div>
              </div>
            ))}

          {timeSeriesData.filter((p) => p.day <= currentDay && p.alertTriggered).length === 0 && (
            <div className="text-center text-slate-500 text-xs py-4">
              No automated alerts triggered up to Day {currentDay}. Pipeline operational.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
