import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Bot,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Layers,
  ArrowRight,
  HelpCircle,
  RefreshCw,
} from 'lucide-react';
import { FeatureDriftResult, SchemaViolation, ValidationSummary } from '../types/pipeline';

interface AiDriftDiagnosticModalProps {
  isOpen: boolean;
  onClose: () => void;
  datasetName: string;
  validationSummary: ValidationSummary;
  driftResults: FeatureDriftResult[];
}

export const AiDriftDiagnosticModal: React.FC<AiDriftDiagnosticModalProps> = ({
  isOpen,
  onClose,
  datasetName,
  validationSummary,
  driftResults,
}) => {
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const runAiAnalysis = async () => {
    setLoading(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/gemini/analyze-drift', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          datasetName,
          pipelineSummary: {
            healthScore: validationSummary.healthScore,
            failedRulesCount: validationSummary.failedRulesCount,
            totalRecords: validationSummary.totalRecordsChecked,
          },
          driftResults: driftResults.map((r) => ({
            feature: r.featureName,
            status: r.driftStatus,
            psi: r.psiScore,
            ksD: r.ksStatistic,
            meanShift: r.meanShiftPct,
          })),
          validationErrors: validationSummary.violations.map((v) => ({
            feature: v.featureName,
            type: v.violationType,
            severity: v.severity,
            desc: v.description,
          })),
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        if (data.fallbackAnalysis) {
          setAnalysis(data.fallbackAnalysis);
        } else {
          throw new Error(data.error || 'Failed to analyze drift');
        }
      } else {
        setAnalysis(data);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to connect to AI diagnostic server.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl p-6 shadow-2xl relative animate-scaleIn text-white">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5 border-b border-slate-800 pb-4">
          <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center">
            <Bot className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>AI-Powered Drift Root Cause Diagnostic</span>
              <span className="text-[10px] bg-purple-500/10 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded font-mono">
                Gemini 3.6 Flash
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Generates an executive diagnostic explanation, probable real-world engineering root causes, and remediation guidance.
            </p>
          </div>
        </div>

        {!analysis && !loading && (
          <div className="text-center py-8 space-y-4">
            <Sparkles className="w-12 h-12 text-purple-400 mx-auto animate-pulse" />
            <h4 className="text-sm font-bold text-slate-200">
              Analyze Current Drift & Validation Audit with Gemini
            </h4>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Our server-side AI model will parse current KS-statistics, PSI decile distributions, and schema contract errors to provide a expert diagnostic report.
            </p>
            <button
              onClick={runAiAnalysis}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-600/20 border border-purple-400/30 transition-all inline-flex items-center gap-2"
            >
              <Cpu className="w-4 h-4" />
              <span>Run AI Root Cause Diagnostic</span>
            </button>
          </div>
        )}

        {loading && (
          <div className="text-center py-12 space-y-3">
            <RefreshCw className="w-8 h-8 text-purple-400 animate-spin mx-auto" />
            <p className="text-xs text-purple-300 font-mono">
              Analyzing statistical matrices and schema violations via Gemini...
            </p>
          </div>
        )}

        {errorMsg && (
          <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-500/40 text-xs text-rose-300 mb-4">
            {errorMsg}
          </div>
        )}

        {analysis && (
          <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1 text-xs">
            {/* Executive Summary */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-[10px] text-purple-400 font-mono font-bold uppercase">Executive Summary</span>
              <p className="text-slate-200 leading-relaxed font-medium">{analysis.summary}</p>
            </div>

            {/* Root Cause & Impact */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                <span className="text-[10px] text-amber-400 font-mono font-bold uppercase">Plausible Root Cause</span>
                <p className="text-slate-300 text-[11px] leading-normal">{analysis.rootCause}</p>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                <span className="text-[10px] text-rose-400 font-mono font-bold uppercase">Business & Model Impact</span>
                <p className="text-slate-300 text-[11px] leading-normal">{analysis.businessImpact}</p>
              </div>
            </div>

            {/* Actionable Engineering Steps */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <span className="text-[10px] text-emerald-400 font-mono font-bold uppercase">
                Recommended Remediation Engineering Steps
              </span>
              <ul className="space-y-1.5">
                {analysis.remediationSteps?.map((step: string, idx: number) => (
                  <li key={idx} className="flex items-start gap-2 text-slate-300 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Student Tip */}
            {analysis.collegeExplanationTip && (
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-800/40 text-amber-200 text-[11px] flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong>Tip for your Professor Presentation:</strong> {analysis.collegeExplanationTip}
                </div>
              </div>
            )}

            <div className="pt-3 border-t border-slate-800 flex justify-between items-center">
              <button
                onClick={runAiAnalysis}
                className="text-xs text-purple-300 hover:text-purple-200 flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" /> Re-analyze
              </button>
              <button
                onClick={onClose}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
