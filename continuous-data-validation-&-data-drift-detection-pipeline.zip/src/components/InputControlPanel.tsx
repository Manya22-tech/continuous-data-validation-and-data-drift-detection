import React, { useState } from 'react';
import {
  SlidersHorizontal,
  Upload,
  Database,
  AlertTriangle,
  Sparkles,
  RefreshCw,
  Sliders,
  Settings2,
  FileText,
  Zap,
} from 'lucide-react';
import Papa from 'papaparse';
import { BatchScenario, DataRecord } from '../types/pipeline';

interface InputControlPanelProps {
  scenarioKey: 'fraud' | 'churn' | 'health';
  onSelectScenario: (key: 'fraud' | 'churn' | 'health') => void;
  batchType: 'normal' | 'drift' | 'corrupt';
  onSelectBatchType: (type: 'normal' | 'drift' | 'corrupt') => void;
  meanShiftPct: number;
  setMeanShiftPct: (val: number) => void;
  nullInjectPct: number;
  setNullInjectPct: (val: number) => void;
  ksPValueThreshold: number;
  setKsPValueThreshold: (val: number) => void;
  psiWarningThreshold: number;
  setPsiWarningThreshold: (val: number) => void;
  psiCriticalThreshold: number;
  setPsiCriticalThreshold: (val: number) => void;
  currentScenario: BatchScenario;
  onCustomCsvLoaded: (name: string, data: DataRecord[]) => void;
  onResetToDefaults: () => void;
}

export const InputControlPanel: React.FC<InputControlPanelProps> = ({
  scenarioKey,
  onSelectScenario,
  batchType,
  onSelectBatchType,
  meanShiftPct,
  setMeanShiftPct,
  nullInjectPct,
  setNullInjectPct,
  ksPValueThreshold,
  setKsPValueThreshold,
  psiWarningThreshold,
  setPsiWarningThreshold,
  psiCriticalThreshold,
  setPsiCriticalThreshold,
  currentScenario,
  onCustomCsvLoaded,
  onResetToDefaults,
}) => {
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  const [csvUploadStatus, setCsvUploadStatus] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setCsvUploadStatus('Parsing CSV file...');
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      complete: (results) => {
        if (results.data && results.data.length > 0) {
          const parsedRecords = results.data.map((row: any, idx: number) => ({
            id: row.id || `custom_${idx + 1}`,
            ...row,
          }));
          onCustomCsvLoaded(file.name, parsedRecords);
          setCsvUploadStatus(`Loaded ${parsedRecords.length} records from ${file.name}`);
        } else {
          setCsvUploadStatus('CSV file was empty or invalid.');
        }
      },
      error: (err) => {
        setCsvUploadStatus(`Failed to parse CSV: ${err.message}`);
      },
    });
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl text-white mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-5">
        <div>
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5 text-indigo-400" />
            <h2 className="text-base font-bold text-slate-100">
              Pipeline Input & Scenario Controls
            </h2>
            <span className="text-xs bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded font-mono">
              Input -&gt; Pipeline Execution
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Configure reference dataset baseline and operational batch conditions to test live validation and drift detection outputs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAdvancedSettings(!showAdvancedSettings)}
            className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border transition-all ${
              showAdvancedSettings
                ? 'bg-slate-800 text-indigo-300 border-indigo-500/40'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>Statistical Thresholds</span>
          </button>

          <button
            onClick={onResetToDefaults}
            className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all"
            title="Reset to default scenario values"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
            <span>Reset Inputs</span>
          </button>
        </div>
      </div>

      {/* Main Control Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Step 1: Select Domain Scenario */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-indigo-400" />
              1. Enterprise ML Domain
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Reference Baseline</span>
          </label>
          <div className="grid grid-cols-1 gap-2">
            <button
              onClick={() => onSelectScenario('fraud')}
              className={`p-3 rounded-xl border text-left transition-all ${
                scenarioKey === 'fraud'
                  ? 'bg-indigo-950/60 border-indigo-500 text-white shadow-lg shadow-indigo-950/50'
                  : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-100">Credit Card Fraud Detection</span>
                <span className="text-[10px] text-indigo-400 font-mono">FinTech</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                Amount, credit score, device type, risk index.
              </p>
            </button>

            <button
              onClick={() => onSelectScenario('churn')}
              className={`p-3 rounded-xl border text-left transition-all ${
                scenarioKey === 'churn'
                  ? 'bg-indigo-950/60 border-indigo-500 text-white shadow-lg shadow-indigo-950/50'
                  : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-100">Customer Churn Predictor</span>
                <span className="text-[10px] text-indigo-400 font-mono">SaaS / Telecom</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                Monthly charges, support tickets, tenure, contract type.
              </p>
            </button>

            <button
              onClick={() => onSelectScenario('health')}
              className={`p-3 rounded-xl border text-left transition-all ${
                scenarioKey === 'health'
                  ? 'bg-indigo-950/60 border-indigo-500 text-white shadow-lg shadow-indigo-950/50'
                  : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-100">ICU Bedside Risk Engine</span>
                <span className="text-[10px] text-indigo-400 font-mono">Healthcare</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                Glucose, blood pressure, heart rate, oxygen SPO2.
              </p>
            </button>
          </div>
        </div>

        {/* Step 2: Select Operational Batch Condition */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              2. Operational Batch Scenario
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Inference Ingestion</span>
          </label>
          <div className="grid grid-cols-1 gap-2">
            <button
              onClick={() => onSelectBatchType('normal')}
              className={`p-3 rounded-xl border text-left transition-all ${
                batchType === 'normal'
                  ? 'bg-emerald-950/50 border-emerald-500 text-white shadow-lg shadow-emerald-950/50'
                  : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  Stable Batch (No Drift)
                </span>
                <span className="text-[10px] text-emerald-400 font-mono">PSI &lt; 0.05</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Ingested payload matches training distribution cleanly. All validation checks pass.
              </p>
            </button>

            <button
              onClick={() => onSelectBatchType('drift')}
              className={`p-3 rounded-xl border text-left transition-all ${
                batchType === 'drift'
                  ? 'bg-amber-950/50 border-amber-500 text-white shadow-lg shadow-amber-950/50'
                  : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                  Covariate Data Drift
                </span>
                <span className="text-[10px] text-amber-400 font-mono">PSI &gt; 0.25</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Distribution shift in feature values (e.g. holiday surge, price change, calibration shift).
              </p>
            </button>

            <button
              onClick={() => onSelectBatchType('corrupt')}
              className={`p-3 rounded-xl border text-left transition-all ${
                batchType === 'corrupt'
                  ? 'bg-rose-950/50 border-rose-500 text-white shadow-lg shadow-rose-950/50'
                  : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                  Schema & API Corruption
                </span>
                <span className="text-[10px] text-rose-400 font-mono">Errors</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Upstream payload contains nulls, out-of-bounds numbers, and unallowed types.
              </p>
            </button>
          </div>
        </div>

        {/* Step 3: Interactive Live Input Modifiers & Custom CSV */}
        <div className="space-y-4 bg-slate-950/50 p-4 rounded-xl border border-slate-800">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              3. Live Input Modifiers
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">Realtime Manipulation</span>
          </label>

          {/* Interactive Slider: Numerical Mean Shift */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Mean Value Shift:</span>
              <span className={`font-mono font-bold ${meanShiftPct !== 0 ? 'text-amber-400' : 'text-slate-300'}`}>
                {meanShiftPct > 0 ? `+${meanShiftPct}%` : `${meanShiftPct}%`}
              </span>
            </div>
            <input
              type="range"
              min="-80"
              max="150"
              value={meanShiftPct}
              onChange={(e) => setMeanShiftPct(Number(e.target.value))}
              className="w-full accent-indigo-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
            />
            <p className="text-[10px] text-slate-500">
              Shift numerical feature distributions upwards or downwards to observe live PSI change.
            </p>
          </div>

          {/* Interactive Slider: Null Injection */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400">Inject Null Anomalies:</span>
              <span className={`font-mono font-bold ${nullInjectPct > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                {nullInjectPct}% nulls
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="35"
              value={nullInjectPct}
              onChange={(e) => setNullInjectPct(Number(e.target.value))}
              className="w-full accent-rose-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
            />
            <p className="text-[10px] text-slate-500">
              Randomly inject missing null values into incoming batch payload.
            </p>
          </div>

          {/* Custom CSV File Upload Button */}
          <div className="pt-2 border-t border-slate-800/80">
            <label className="text-[11px] font-medium text-slate-300 mb-1 block">
              Upload Custom Batch CSV:
            </label>
            <label className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 hover:border-slate-500 text-xs text-slate-300 cursor-pointer transition-all">
              <Upload className="w-3.5 h-3.5 text-indigo-400" />
              <span>Choose CSV File...</span>
              <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
            </label>
            {csvUploadStatus && (
              <p className="text-[10px] text-cyan-300 mt-1 font-mono truncate">{csvUploadStatus}</p>
            )}
          </div>
        </div>
      </div>

      {/* Current Scenario Notes Banner */}
      <div className="mt-4 p-3 rounded-xl bg-indigo-950/30 border border-indigo-800/40 flex items-start gap-3">
        <Sparkles className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <div className="text-xs">
          <span className="font-bold text-indigo-200">Active Scenario Description: </span>
          <span className="text-slate-300">{currentScenario.description}</span>
          <div className="mt-1 font-mono text-[11px] text-indigo-300/90">
            {batchType === 'normal' && currentScenario.scenarioNotes.normalBatchDesc}
            {batchType === 'drift' && currentScenario.scenarioNotes.driftBatchDesc}
            {batchType === 'corrupt' && currentScenario.scenarioNotes.schemaErrorDesc}
          </div>
        </div>
      </div>

      {/* Advanced Statistical Sensitivity Modal / Expandable Drawer */}
      {showAdvancedSettings && (
        <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-4 animate-fadeIn">
          <h4 className="text-xs font-bold text-indigo-300 flex items-center gap-2">
            <Settings2 className="w-4 h-4 text-indigo-400" />
            Statistical Test & Rule Sensitivity Settings
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="space-y-1">
              <span className="text-slate-400">KS-Test Alpha ($p$-value cutoff):</span>
              <input
                type="number"
                step="0.01"
                min="0.001"
                max="0.20"
                value={ksPValueThreshold}
                onChange={(e) => setKsPValueThreshold(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-white font-mono"
              />
              <span className="text-[10px] text-slate-500">Default $\alpha = 0.05$</span>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400">PSI Moderate Warning Threshold:</span>
              <input
                type="number"
                step="0.01"
                min="0.05"
                max="0.20"
                value={psiWarningThreshold}
                onChange={(e) => setPsiWarningThreshold(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-white font-mono"
              />
              <span className="text-[10px] text-slate-500">Default PSI = 0.10</span>
            </div>

            <div className="space-y-1">
              <span className="text-slate-400">PSI Critical Action Threshold:</span>
              <input
                type="number"
                step="0.01"
                min="0.15"
                max="0.50"
                value={psiCriticalThreshold}
                onChange={(e) => setPsiCriticalThreshold(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-white font-mono"
              />
              <span className="text-[10px] text-slate-500">Default PSI = 0.25</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
