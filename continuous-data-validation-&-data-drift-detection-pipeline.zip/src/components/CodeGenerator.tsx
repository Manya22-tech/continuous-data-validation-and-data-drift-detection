import React, { useState } from 'react';
import { Code2, Copy, Check, Terminal, FileCode, Layers } from 'lucide-react';
import { FeatureSchema } from '../types/pipeline';

interface CodeGeneratorProps {
  schemas: FeatureSchema[];
  ksPValueThreshold: number;
  psiWarningThreshold: number;
  psiCriticalThreshold: number;
  datasetName: string;
}

export const CodeGenerator: React.FC<CodeGeneratorProps> = ({
  schemas,
  ksPValueThreshold,
  psiWarningThreshold,
  psiCriticalThreshold,
  datasetName,
}) => {
  const [activeFramework, setActiveFramework] = useState<'pyspark' | 'great_expectations' | 'evidently'>('pyspark');
  const [copied, setCopied] = useState(false);

  // Generate PySpark / Great Expectations code dynamically matching active schemas
  const generateCode = () => {
    if (activeFramework === 'pyspark') {
      return `# PySpark Continuous Data Drift & Validation Pipeline
# Target System: ${datasetName}
import pyspark.sql.functions as F
from pyspark.sql import SparkSession
import numpy as np

spark = SparkSession.builder.appName("ContinuousDataValidationPipeline").getOrCreate()

def validate_schema_contract(df):
    """Enforces schema assertions on incoming batch payload"""
    violations = []
    total_records = df.count()

    # Rule Assertions generated from active contract
${schemas
  .map((s) => {
    if (s.type === 'numerical') {
      return `    # Feature: ${s.name}
    null_count = df.filter(F.col("${s.name}").isNull()).count()
    if null_count > ${s.maxNullPercentage / 100} * total_records:
        violations.append("${s.name}: Null count exceeded ${s.maxNullPercentage}% threshold")
    
    out_of_bounds = df.filter((F.col("${s.name}") < ${s.minAllowed ?? -999999}) | (F.col("${s.name}") > ${s.maxAllowed ?? 999999})).count()
    if out_of_bounds > 0:
        violations.append(f"${s.name}: {out_of_bounds} records fell outside [${s.minAllowed}, ${s.maxAllowed}] bounds")`;
    } else {
      return `    # Feature: ${s.name} (Categorical)
    allowed_cats = ${JSON.stringify(s.allowedCategories || [])}
    invalid_cats = df.filter(~F.col("${s.name}").isin(allowed_cats)).count()
    if invalid_cats > 0:
        violations.append(f"${s.name}: Found {invalid_cats} invalid categorical tokens")`;
    }
  })
  .join('\n\n')}

    return violations

def calculate_psi(baseline_arr, current_arr, num_bins=10):
    """Calculates Population Stability Index across decile bins"""
    min_val = min(min(baseline_arr), min(current_arr))
    max_val = max(max(baseline_arr), max(current_arr))
    bins = np.linspace(min_val, max_val, num_bins + 1)
    
    b_counts, _ = np.histogram(baseline_arr, bins=bins)
    c_counts, _ = np.histogram(current_arr, bins=bins)
    
    b_pct = np.maximum(0.0001, b_counts / len(baseline_arr))
    c_pct = np.maximum(0.0001, c_counts / len(current_arr))
    
    psi = np.sum((c_pct - b_pct) * np.log(c_pct / b_pct))
    return round(float(psi), 4)

print("Enterprise Data Validation & Drift Pipeline Ready.")
`;
    }

    if (activeFramework === 'great_expectations') {
      return `# Great Expectations Data Quality Suite
import great_expectations as ge

def run_great_expectations_contract(batch_df):
    ge_df = ge.from_pandas(batch_df)

    # Generated Expectation Suite for ${datasetName}
${schemas
  .map((s) => {
    if (s.type === 'numerical') {
      return `    ge_df.expect_column_values_to_not_be_null("${s.name}", mostly=${1 - s.maxNullPercentage / 100})
    ge_df.expect_column_values_to_be_between("${s.name}", min_value=${s.minAllowed ?? 0}, max_value=${s.maxAllowed ?? 10000})`;
    } else {
      return `    ge_df.expect_column_values_to_be_in_set("${s.name}", value_set=${JSON.stringify(s.allowedCategories || [])})`;
    }
  })
  .join('\n')}

    results = ge_df.validate()
    print("Health Score:", results["statistics"]["success_percent"])
    return results
`;
    }

    return `# Evidently AI Data Drift Suite
from evidently.report import Report
from evidently.metric_preset import DataDriftPreset, DataQualityPreset

def generate_drift_report(reference_df, current_df):
    drift_report = Report(metrics=[
        DataQualityPreset(),
        DataDriftPreset(stattest_threshold=${ksPValueThreshold})
    ])
    
    drift_report.run(reference_data=reference_df, current_data=current_df)
    drift_report.save_html("data_drift_audit_report.html")
    print("Report saved to data_drift_audit_report.html")
`;
  };

  const codeText = generateCode();

  const handleCopy = () => {
    navigator.clipboard.writeText(codeText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl text-white mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center">
            <Code2 className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>Production Pipeline Code Generator</span>
            </h3>
            <p className="text-xs text-slate-400">
              Generates executable Python scripts matching current schema contracts and drift thresholds.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs flex items-center gap-1">
            <button
              onClick={() => setActiveFramework('pyspark')}
              className={`px-3 py-1 rounded transition-all ${
                activeFramework === 'pyspark' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              PySpark
            </button>
            <button
              onClick={() => setActiveFramework('great_expectations')}
              className={`px-3 py-1 rounded transition-all ${
                activeFramework === 'great_expectations' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Great Expectations
            </button>
            <button
              onClick={() => setActiveFramework('evidently')}
              className={`px-3 py-1 rounded transition-all ${
                activeFramework === 'evidently' ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Evidently AI
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono text-xs overflow-x-auto text-slate-300 max-h-96 leading-relaxed">
        <pre>{codeText}</pre>
      </div>
    </div>
  );
};
