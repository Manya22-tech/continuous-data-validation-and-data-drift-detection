import React, { useState } from 'react';
import {
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  BarChart3,
  BarChart2,
  ArrowUpRight,
  ArrowDownRight,
  Info,
  Layers,
  X,
  Sliders,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { FeatureDriftResult, OverallDriftSummary } from '../types/pipeline';

interface DataDriftDashboardProps {
  driftResults: FeatureDriftResult[];
  overallSummary: OverallDriftSummary;
  ksPValueThreshold: number;
  psiWarningThreshold: number;
  psiCriticalThreshold: number;
}

export const DataDriftDashboard: React.FC<DataDriftDashboardProps> = ({
  driftResults,
  overallSummary,
  ksPValueThreshold,
  psiWarningThreshold,
  psiCriticalThreshold,
}) => {
  const [selectedFeature, setSelectedFeature] = useState<FeatureDriftResult | null>(null);

  const getStatusBadge = (status: 'NO_DRIFT' | 'MODERATE_DRIFT' | 'CRITICAL_DRIFT') => {
    if (status === 'NO_DRIFT') {
      return {
        label: 'STABLE (NO DRIFT)',
        bg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
        icon: <CheckCircle2 className="w-3.5 h-3.5" />,
      };
    }
    if (status === 'MODERATE_DRIFT') {
      return {
        label: 'MODERATE DRIFT',
        bg: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
        icon: <AlertTriangle className="w-3.5 h-3.5" />,
      };
    }
    return {
      label: 'CRITICAL DRIFT',
      bg: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
      icon: <XCircle className="w-3.5 h-3.5" />,
    };
  };

  const getOverallAlert = (status: string) => {
    if (status === 'STABLE') {
      return {
        title: 'PIPELINE STABLE: No Covariate Drift Detected',
        desc: 'Incoming operational feature distributions align smoothly with reference training dataset (Average PSI < 0.10). Model prediction accuracy is protected.',
        bg: 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200',
        icon: <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />,
      };
    }
    if (status === 'MODERATE_WARNING') {
      return {
        title: 'MODERATE DRIFT ALERT: Distribution Shift Detected',
        desc: `Observed moderate statistical shift in ${overallSummary.moderateDriftCount} features. Monitor model prediction confidence metrics closely.`,
        bg: 'bg-amber-950/40 border-amber-500/40 text-amber-200',
        icon: <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 animate-bounce" />,
      };
    }
    return {
      title: 'CRITICAL DRIFT ALERT: Automated Pipeline Action Required',
      desc: `Severe statistical drift detected in ${overallSummary.criticalDriftCount} core features. Estimated model accuracy drop: -${overallSummary.predictedModelAccuracyDrop}%. Automated model retraining or batch quarantine triggered.`,
      bg: 'bg-rose-950/40 border-rose-500/40 text-rose-200',
      icon: <XCircle className="w-5 h-5 text-rose-400 shrink-0 animate-pulse" />,
    };
  };

  const alertBox = getOverallAlert(overallSummary.overallStatus);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl text-white mb-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100">
              Output 2: Continuous Data Drift Analysis Engine
            </h3>
            <p className="text-xs text-slate-400">
              Performs Kolmogorov-Smirnov (KS-Test), Population Stability Index (PSI), and Wasserstein distance tests between baseline reference & operational batch.
            </p>
          </div>
        </div>
      </div>

      {/* Overall Banner */}
      <div className={`p-4 rounded-xl border flex items-start gap-3.5 mb-6 ${alertBox.bg}`}>
        {alertBox.icon}
        <div>
          <h4 className="text-sm font-bold flex items-center gap-2">
            <span>{alertBox.title}</span>
            <span className="text-[10px] bg-slate-900/60 px-2 py-0.5 rounded border border-slate-700 font-mono">
              Avg PSI: {overallSummary.averagePsi}
            </span>
          </h4>
          <p className="text-xs mt-1 opacity-90">{alertBox.desc}</p>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5 mb-6">
        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
          <span className="text-slate-400 text-[11px]">Total Features</span>
          <div className="text-xl font-bold font-mono text-slate-100">{overallSummary.totalFeatures}</div>
          <span className="text-[10px] text-slate-500">Monitored metrics</span>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
          <span className="text-slate-400 text-[11px]">Drifted Features</span>
          <div className="text-xl font-bold font-mono text-amber-400">
            {overallSummary.driftedFeaturesCount}
            <span className="text-xs text-slate-500 font-normal ml-1">/ {overallSummary.totalFeatures}</span>
          </div>
          <span className="text-[10px] text-amber-400/80">PSI &ge; {psiWarningThreshold}</span>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
          <span className="text-slate-400 text-[11px]">Average PSI Score</span>
          <div
            className={`text-xl font-bold font-mono ${
              overallSummary.averagePsi >= psiCriticalThreshold
                ? 'text-rose-400'
                : overallSummary.averagePsi >= psiWarningThreshold
                ? 'text-amber-400'
                : 'text-emerald-400'
            }`}
          >
            {overallSummary.averagePsi}
          </div>
          <span className="text-[10px] text-slate-500">Population Stability</span>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
          <span className="text-slate-400 text-[11px]">Max KS-Statistic (D)</span>
          <div className="text-xl font-bold font-mono text-cyan-400">
            {overallSummary.maxKsStatistic}
          </div>
          <span className="text-[10px] text-slate-500">Max CDF distance</span>
        </div>

        <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 col-span-2 sm:col-span-1">
          <span className="text-slate-400 text-[11px]">Predicted ML Acc. Drop</span>
          <div
            className={`text-xl font-bold font-mono ${
              overallSummary.predictedModelAccuracyDrop > 10 ? 'text-rose-400' : 'text-slate-200'
            }`}
          >
            -{overallSummary.predictedModelAccuracyDrop}%
          </div>
          <span className="text-[10px] text-slate-500">Estimated accuracy decay</span>
        </div>
      </div>

      {/* Statistical Matrix Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60 mb-4">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/80 text-slate-400 font-mono text-[11px]">
              <th className="p-3">Feature Name</th>
              <th className="p-3">Type</th>
              <th className="p-3">Baseline Mean (Std)</th>
              <th className="p-3">Current Mean (Std)</th>
              <th className="p-3">KS-Statistic (D)</th>
              <th className="p-3">PSI Score</th>
              <th className="p-3">Wasserstein Dist</th>
              <th className="p-3">Drift Status</th>
              <th className="p-3 text-right">Inspect Chart</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-300">
            {driftResults.map((res) => {
              const statusBadge = getStatusBadge(res.driftStatus);
              return (
                <tr key={res.featureName} className="hover:bg-slate-900/50 transition-colors">
                  <td className="p-3 font-bold font-mono text-indigo-300 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-slate-500" />
                    {res.featureName}
                  </td>
                  <td className="p-3 font-mono text-[10px] text-slate-400 uppercase">{res.featureType}</td>
                  <td className="p-3 font-mono">
                    {res.featureType === 'numerical' ? (
                      <span>
                        {res.baselineMean}{' '}
                        <span className="text-[10px] text-slate-500">(&plusmn;{res.baselineStd})</span>
                      </span>
                    ) : (
                      <span className="text-slate-500">-</span>
                    )}
                  </td>
                  <td className="p-3 font-mono">
                    {res.featureType === 'numerical' ? (
                      <span className="flex items-center gap-1">
                        {res.currentMean}{' '}
                        <span className="text-[10px] text-slate-500">(&plusmn;{res.currentStd})</span>
                        {res.meanShiftPct !== 0 && (
                          <span
                            className={`text-[10px] font-bold ${
                              Math.abs(res.meanShiftPct || 0) > 20 ? 'text-amber-400' : 'text-slate-400'
                            }`}
                          >
                            ({(res.meanShiftPct || 0) > 0 ? '+' : ''}
                            {res.meanShiftPct}%)
                          </span>
                        )}
                      </span>
                    ) : (
                      <span className="text-slate-500">-</span>
                    )}
                  </td>
                  <td className="p-3 font-mono">
                    {res.ksStatistic !== undefined ? (
                      <div>
                        <span className="font-bold text-slate-100">{res.ksStatistic}</span>
                        <span className="text-[10px] text-slate-500 block">p = {res.ksPValue}</span>
                      </div>
                    ) : (
                      <span className="text-slate-500">Chi² = {res.chiSquareStat}</span>
                    )}
                  </td>
                  <td className="p-3 font-mono">
                    <span
                      className={`font-bold ${
                        res.psiScore >= psiCriticalThreshold
                          ? 'text-rose-400'
                          : res.psiScore >= psiWarningThreshold
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {res.psiScore}
                    </span>
                  </td>
                  <td className="p-3 font-mono text-slate-400">
                    {res.wassersteinDistance !== undefined ? res.wassersteinDistance : '-'}
                  </td>
                  <td className="p-3">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border ${statusBadge.bg}`}
                    >
                      {statusBadge.icon}
                      {statusBadge.label}
                    </span>
                  </td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => setSelectedFeature(res)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700 transition-all"
                    >
                      <BarChart3 className="w-3.5 h-3.5" />
                      <span>Inspect</span>
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Feature Distribution Overlay Modal */}
      {selectedFeature && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl p-6 shadow-2xl animate-scaleIn relative">
            <button
              onClick={() => setSelectedFeature(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-4">
              <BarChart2 className="w-5 h-5 text-indigo-400" />
              <div>
                <h3 className="text-base font-bold text-slate-100">
                  Feature Distribution Shift: <span className="text-indigo-300 font-mono">{selectedFeature.featureName}</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Overlay histogram comparison: Reference Training Baseline (Blue) vs Operational Inference Batch (Amber).
                </p>
              </div>
            </div>

            {/* Metrics Breakdown Bar inside Modal */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5 text-xs bg-slate-950/80 p-3 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-400">PSI Score:</span>
                <span className="block font-mono font-bold text-amber-400 text-sm">
                  {selectedFeature.psiScore}
                </span>
              </div>
              <div>
                <span className="text-slate-400">KS-Statistic D:</span>
                <span className="block font-mono font-bold text-cyan-400 text-sm">
                  {selectedFeature.ksStatistic ?? 'N/A'}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Wasserstein Distance:</span>
                <span className="block font-mono font-bold text-slate-200 text-sm">
                  {selectedFeature.wassersteinDistance ?? 'N/A'}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Drift Assessment:</span>
                <span className="block font-bold text-amber-300 text-xs mt-0.5">
                  {selectedFeature.driftStatus}
                </span>
              </div>
            </div>

            {/* Recharts Bar Chart */}
            <div className="h-72 w-full bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
              {selectedFeature.featureType === 'numerical' && selectedFeature.bins.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={selectedFeature.bins} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="binLabel" stroke="#94a3b8" fontSize={10} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} unit="%" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                      itemStyle={{ color: '#f8fafc' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                    <Bar dataKey="baselinePct" name="Baseline Training %" fill="#6366f1" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="currentPct" name="Current Batch %" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : selectedFeature.categoricalDistribution ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={selectedFeature.categoricalDistribution} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="category" stroke="#94a3b8" fontSize={10} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} unit="%" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                    <Bar dataKey="baselinePct" name="Baseline %" fill="#6366f1" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="currentPct" name="Current %" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-slate-500 text-xs">
                  No histogram bins available for this feature.
                </div>
              )}
            </div>

            <div className="mt-4 text-right">
              <button
                onClick={() => setSelectedFeature(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200"
              >
                Close Visualizer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
