export type DataType = 'numerical' | 'categorical';

export interface FeatureSchema {
  name: string;
  type: DataType;
  unit?: string;
  minAllowed?: number;
  maxAllowed?: number;
  allowedCategories?: string[];
  allowNulls: boolean;
  maxNullPercentage: number; // e.g. 5.0 = max 5% nulls
  description: string;
}

export interface DataRecord {
  id: string | number;
  [key: string]: any;
}

export interface SchemaViolation {
  id: string;
  featureName: string;
  violationType: 'MISSING_COLUMN' | 'NULL_THRESHOLD_EXCEEDED' | 'TYPE_MISMATCH' | 'RANGE_OUT_OF_BOUNDS' | 'UNALLOWED_CATEGORY';
  severity: 'CRITICAL' | 'WARNING';
  affectedCount: number;
  affectedPercentage: number;
  description: string;
  suggestedFix: string;
}

export interface ValidationSummary {
  totalRecordsChecked: number;
  totalFeaturesChecked: number;
  passedRulesCount: number;
  failedRulesCount: number;
  healthScore: number; // 0 to 100
  violations: SchemaViolation[];
}

export interface HistogramBin {
  binLabel: string;
  binStart: number;
  binEnd: number;
  baselinePct: number;
  currentPct: number;
  baselineCount: number;
  currentCount: number;
  binPsi: number;
}

export interface FeatureDriftResult {
  featureName: string;
  featureType: DataType;
  baselineMean?: number;
  currentMean?: number;
  meanShiftPct?: number;
  baselineStd?: number;
  currentStd?: number;
  ksStatistic?: number; // Kolmogorov-Smirnov D statistic
  ksPValue?: number;
  psiScore: number; // Population Stability Index
  wassersteinDistance?: number;
  chiSquareStat?: number;
  chiSquarePValue?: number;
  driftStatus: 'NO_DRIFT' | 'MODERATE_DRIFT' | 'CRITICAL_DRIFT';
  bins: HistogramBin[];
  categoricalDistribution?: {
    category: string;
    baselinePct: number;
    currentPct: number;
  }[];
  unseenCategoriesFound?: string[];
}

export interface OverallDriftSummary {
  totalFeatures: number;
  driftedFeaturesCount: number;
  criticalDriftCount: number;
  moderateDriftCount: number;
  noDriftCount: number;
  averagePsi: number;
  maxKsStatistic: number;
  predictedModelAccuracyDrop: number; // e.g. 12.5 = estimated 12.5% accuracy drop
  overallStatus: 'STABLE' | 'MODERATE_WARNING' | 'CRITICAL_ACTION_REQUIRED';
}

export interface PipelineAlert {
  id: string;
  timestamp: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  title: string;
  description: string;
  actionTaken: string;
}

export interface BatchScenario {
  id: string;
  name: string;
  domain: string;
  description: string;
  targetModel: string;
  schemas: FeatureSchema[];
  baselineData: DataRecord[];
  currentBatchData: DataRecord[];
  scenarioNotes: {
    normalBatchDesc: string;
    driftBatchDesc: string;
    schemaErrorDesc: string;
  };
}

export interface TimeSeriesPoint {
  day: number;
  dateStr: string;
  overallPsi: number;
  driftedFeatureCount: number;
  healthScore: number;
  featurePsiMap: Record<string, number>;
  alertTriggered?: string;
}
